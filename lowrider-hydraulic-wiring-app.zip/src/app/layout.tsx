import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Switchcraft — Lowrider Hydraulic Field School", template: "%s · Switchcraft" },
  description: "Interactive 2, 4, 6 and 8-pump hydraulic plans, color-coded switch-box wiring, step-by-step lessons and a multi-vendor parts desk for cars from 1920 to today.",
  applicationName: "Switchcraft",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "Switchcraft" },
  icons: { icon: "/icons/icon.svg", apple: "/icons/icon-512.png" },
};

export const viewport: Viewport = {
  themeColor: "#101411",
  colorScheme: "dark light",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
