import type { Metadata } from "next";

export const metadata: Metadata = { title: "Offline" };

export default function OfflinePage() {
  return <main className="offline-page"><div><span className="eyebrow">SWITCHCRAFT / OFFLINE</span><h1>The garage signal dropped.</h1><p>The app shell is available, but this page was not cached. Reconnect to sync saved builds, open supplier listings and load new workshop material.</p><a className="button button-acid" href="/">Try the workshop again</a><small>Previously exported SVG, JSON and CSV files remain available in your device downloads.</small></div></main>;
}
