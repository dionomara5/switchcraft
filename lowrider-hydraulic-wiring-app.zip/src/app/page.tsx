import SwitchcraftApp from "@/components/app";

export default function HomePage() {
  return <SwitchcraftApp />;
}
