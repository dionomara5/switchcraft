import { NextResponse } from "next/server";
import Stripe from "stripe";
import { requireMember } from "@/lib/session";

export async function POST(request: Request) {
  try {
    const member = await requireMember();
    const { interval } = await request.json() as { interval?: "monthly" | "yearly" };
    const key = process.env.STRIPE_SECRET_KEY;
    const price = interval === "yearly" ? process.env.STRIPE_PRICE_ID_YEARLY : process.env.STRIPE_PRICE_ID_MONTHLY;
    if (!key || !price) {
      return NextResponse.json({ error: "Secure membership checkout is not configured in this preview. No charge was made." }, { status: 503 });
    }
    const stripe = new Stripe(key);
    const origin = request.headers.get("origin") ?? new URL(request.url).origin;
    const session = await stripe.checkout.sessions.create({
      mode: "subscription",
      line_items: [{ price, quantity: 1 }],
      client_reference_id: member.id,
      customer: member.stripeCustomerId ?? undefined,
      success_url: `${origin}/?membership=success`,
      cancel_url: `${origin}/?membership=cancelled#membership`,
      metadata: { memberId: member.id },
      subscription_data: { metadata: { memberId: member.id } },
      allow_promotion_codes: true,
    });
    if (!session.url) return NextResponse.json({ error: "Stripe did not return a checkout URL." }, { status: 502 });
    return NextResponse.json({ url: session.url });
  } catch (error) {
    if (error instanceof Error && error.message === "NO_SESSION") return NextResponse.json({ error: "Start a session first." }, { status: 401 });
    return NextResponse.json({ error: "Checkout could not be started. No charge was made." }, { status: 500 });
  }
}
