import { NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { builds } from "@/db/schema";
import { normalizeConfig } from "@/lib/hydraulics";
import { hasAccess, publicMember, requireMember } from "@/lib/session";

export async function GET() {
  try {
    const member = await requireMember();
    const rows = await db.select().from(builds).where(eq(builds.memberId, member.id)).orderBy(desc(builds.updatedAt)).limit(30);
    return NextResponse.json({ builds: rows });
  } catch {
    return NextResponse.json({ error: "Start a session first." }, { status: 401 });
  }
}

export async function POST(request: Request) {
  try {
    const member = await requireMember();
    const body = await request.json() as { name?: string; config?: Parameters<typeof normalizeConfig>[0] };
    const config = normalizeConfig(body.config);
    const access = publicMember(member).status;
    if (config.pumpCount > 4 && !hasAccess(access, "pro")) {
      return NextResponse.json({ error: "Six- and eight-pump build saving requires an active membership." }, { status: 403 });
    }
    const name = String(body.name || `${config.vehicleYear} ${config.vehicleMake} ${config.vehicleModel}`).trim().slice(0, 90);
    const existing = await db.select({ id: builds.id }).from(builds).where(eq(builds.memberId, member.id));
    if (existing.length >= 30) return NextResponse.json({ error: "Your 30 saved-build slots are full. Remove an old plan before saving another." }, { status: 409 });
    const [build] = await db.insert(builds).values({ memberId: member.id, name, config }).returning();
    return NextResponse.json({ build: { id: build.id, name: build.name, config: build.config, updatedAt: build.updatedAt.toISOString() } }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === "NO_SESSION") return NextResponse.json({ error: "Start a session first." }, { status: 401 });
    return NextResponse.json({ error: "The build could not be saved." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const member = await requireMember();
    const { id } = await request.json() as { id?: string };
    if (!id) return NextResponse.json({ error: "Build id is required." }, { status: 400 });
    const [deleted] = await db.delete(builds).where(and(eq(builds.id, id), eq(builds.memberId, member.id))).returning({ id: builds.id });
    if (!deleted) return NextResponse.json({ error: "Build not found." }, { status: 404 });
    return NextResponse.json({ ok: true, id });
  } catch {
    return NextResponse.json({ error: "The build could not be removed." }, { status: 400 });
  }
}
