import { NextResponse } from "next/server";
import Stripe from "stripe";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { members } from "@/db/schema";

export async function POST(request: Request) {
  const key = process.env.STRIPE_SECRET_KEY;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!key || !webhookSecret) return NextResponse.json({ error: "Webhook is not configured." }, { status: 503 });
  const signature = request.headers.get("stripe-signature");
  if (!signature) return NextResponse.json({ error: "Missing signature." }, { status: 400 });
  const stripe = new Stripe(key);
  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(await request.text(), signature, webhookSecret);
  } catch {
    return NextResponse.json({ error: "Invalid signature." }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const memberId = session.metadata?.memberId ?? session.client_reference_id;
    if (memberId) {
      await db.update(members).set({
        status: "active",
        stripeCustomerId: typeof session.customer === "string" ? session.customer : session.customer?.id,
        stripeSubscriptionId: typeof session.subscription === "string" ? session.subscription : session.subscription?.id,
        updatedAt: new Date(),
      }).where(eq(members.id, memberId));
    }
  }

  if (event.type === "customer.subscription.updated" || event.type === "customer.subscription.deleted") {
    const subscription = event.data.object;
    const active = event.type === "customer.subscription.updated" && (subscription.status === "active" || subscription.status === "trialing");
    await db.update(members).set({ status: active ? "active" : "expired", updatedAt: new Date() }).where(eq(members.stripeSubscriptionId, subscription.id));
  }

  return NextResponse.json({ received: true });
}
