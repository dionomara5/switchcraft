import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { builds, lessonProgress, members, shoppingItems } from "@/db/schema";
import { createMember, publicMember, SESSION_COOKIE } from "@/lib/session";
import type { SessionPayload } from "@/lib/api-types";

export async function POST(request: Request) {
  const cookieHeader = request.headers.get("cookie") ?? "";
  const existingToken = cookieHeader.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE}=([^;]+)`))?.[1];
  const token = existingToken ? decodeURIComponent(existingToken) : randomUUID();
  let [member] = await db.select().from(members).where(eq(members.sessionToken, token)).limit(1);
  if (!member) member = await createMember(token);

  const [savedBuilds, progress, shopping] = await Promise.all([
    db.select().from(builds).where(eq(builds.memberId, member.id)).orderBy(desc(builds.updatedAt)).limit(30),
    db.select().from(lessonProgress).where(eq(lessonProgress.memberId, member.id)),
    db.select().from(shoppingItems).where(eq(shoppingItems.memberId, member.id)),
  ]);

  const payload: SessionPayload = {
    member: {
      ...publicMember(member),
      trialEndsAt: member.trialEndsAt.toISOString(),
      createdAt: member.createdAt.toISOString(),
    },
    builds: savedBuilds.map((build) => ({ id: build.id, name: build.name, config: build.config, updatedAt: build.updatedAt.toISOString() })),
    progress: progress.map((entry) => ({ lessonId: entry.lessonId, completed: entry.completed, quizScore: entry.quizScore })),
    shopping: shopping.map((entry) => ({ productId: entry.productId, quantity: entry.quantity })),
  };

  const response = NextResponse.json(payload);
  response.cookies.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 365,
  });
  return response;
}
