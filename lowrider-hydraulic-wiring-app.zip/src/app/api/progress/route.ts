import { NextResponse } from "next/server";
import { db } from "@/db";
import { lessonProgress } from "@/db/schema";
import { LESSONS } from "@/lib/content";
import { hasAccess, publicMember, requireMember } from "@/lib/session";

export async function POST(request: Request) {
  try {
    const member = await requireMember();
    const body = await request.json() as { lessonId?: string; completed?: boolean; quizScore?: number };
    const lesson = LESSONS.find((entry) => entry.id === body.lessonId);
    if (!lesson) return NextResponse.json({ error: "Lesson not found." }, { status: 404 });
    if (!hasAccess(publicMember(member).status, lesson.access)) {
      return NextResponse.json({ error: "This lesson is not included in your current access." }, { status: 403 });
    }
    const values = {
      memberId: member.id,
      lessonId: lesson.id,
      completed: Boolean(body.completed),
      quizScore: Math.max(0, Math.min(100, Number(body.quizScore) || 0)),
      updatedAt: new Date(),
    };
    const [saved] = await db.insert(lessonProgress).values(values).onConflictDoUpdate({
      target: [lessonProgress.memberId, lessonProgress.lessonId],
      set: { completed: values.completed, quizScore: values.quizScore, updatedAt: values.updatedAt },
    }).returning();
    return NextResponse.json({ progress: { lessonId: saved.lessonId, completed: saved.completed, quizScore: saved.quizScore } });
  } catch (error) {
    if (error instanceof Error && error.message === "NO_SESSION") return NextResponse.json({ error: "Start a session first." }, { status: 401 });
    return NextResponse.json({ error: "Progress could not be saved." }, { status: 400 });
  }
}
