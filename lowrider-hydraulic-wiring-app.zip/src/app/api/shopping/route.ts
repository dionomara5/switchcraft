import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { shoppingItems } from "@/db/schema";
import { PRODUCTS } from "@/lib/catalog";
import { requireMember } from "@/lib/session";

export async function POST(request: Request) {
  try {
    const member = await requireMember();
    const body = await request.json() as { productId?: string; quantity?: number };
    const product = PRODUCTS.find((entry) => entry.id === body.productId);
    if (!product) return NextResponse.json({ error: "Product not found." }, { status: 404 });
    const quantity = Math.max(1, Math.min(99, Math.round(Number(body.quantity) || 1)));
    const [saved] = await db.insert(shoppingItems).values({ memberId: member.id, productId: product.id, quantity }).onConflictDoUpdate({
      target: [shoppingItems.memberId, shoppingItems.productId],
      set: { quantity },
    }).returning();
    return NextResponse.json({ item: { productId: saved.productId, quantity: saved.quantity } });
  } catch (error) {
    if (error instanceof Error && error.message === "NO_SESSION") return NextResponse.json({ error: "Start a session first." }, { status: 401 });
    return NextResponse.json({ error: "List could not be updated." }, { status: 400 });
  }
}

export async function DELETE(request: Request) {
  try {
    const member = await requireMember();
    const { productId } = await request.json() as { productId?: string };
    if (!productId) return NextResponse.json({ error: "Product id is required." }, { status: 400 });
    await db.delete(shoppingItems).where(and(eq(shoppingItems.memberId, member.id), eq(shoppingItems.productId, productId)));
    return NextResponse.json({ ok: true, productId });
  } catch {
    return NextResponse.json({ error: "Item could not be removed." }, { status: 400 });
  }
}
