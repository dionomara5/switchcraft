"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useReducedMotion, useScroll, useTransform, type MotionValue } from "framer-motion";
import { ArrowDown, BatteryCharging, CircuitBoard, Cog, Gauge } from "lucide-react";

const MODULES = [
  { id: "power", title: "POWER", subtitle: "Matched battery strings", copy: "Series sets voltage. Parallel strings add capacity. Every connection has a job.", icon: BatteryCharging, color: "#ff6257" },
  { id: "pressure", title: "PRESSURE", subtitle: "Checked pump circuits", copy: "Each outlet moves oil one way. Paired pumps join only after their checks.", icon: Gauge, color: "#f7d54d" },
  { id: "control", title: "CONTROL", subtitle: "Momentary switch logic", copy: "Small signals wake the right solenoids and dumps—never the full motor current.", icon: CircuitBoard, color: "#4aa8ff" },
  { id: "motion", title: "MOTION", subtitle: "Four measured corners", copy: "Cylinders turn pressure into travel. Geometry and structure decide whether it is useful.", icon: Cog, color: "#42db8b" },
];

export default function ScrollScene() {
  const ref = useRef<HTMLElement>(null);
  const reduceMotion = useReducedMotion();
  const [compact, setCompact] = useState(false);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end end"] });
  const introOpacity = useTransform(scrollYProgress, [0, 0.22, 0.45], [1, 1, 0]);
  const finalOpacity = useTransform(scrollYProgress, [0.62, 0.82], [0, 1]);
  const finalScale = useTransform(scrollYProgress, [0.62, 0.88], [0.82, 1]);
  const ringRotate = useTransform(scrollYProgress, [0, 1], [0, 160]);
  const progressScale = useTransform(scrollYProgress, [0, 1], [0, 1]);
  const positions = [
    { x: ["-38vw", "-12vw"], y: ["-34vh", "-13vh"], rotate: [-13, 0] },
    { x: ["38vw", "12vw"], y: ["-34vh", "-13vh"], rotate: [11, 0] },
    { x: ["-38vw", "-12vw"], y: ["34vh", "13vh"], rotate: [9, 0] },
    { x: ["38vw", "12vw"], y: ["34vh", "13vh"], rotate: [-10, 0] },
  ];

  useEffect(() => {
    const media = window.matchMedia("(max-width: 800px)");
    const update = () => setCompact(media.matches);
    update(); media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);

  if (reduceMotion || compact) return <section className="assembly-static section-pad" id="assembly"><div className="page-shell"><span className="eyebrow">ONE CONNECTED SYSTEM</span><h2>Four ideas. One build you can trace.</h2><div className="assembly-static-grid">{MODULES.map((module) => <article key={module.id}><module.icon size={25} style={{ color: module.color }} /><span>{module.subtitle}</span><h3>{module.title}</h3><p>{module.copy}</p></article>)}</div></div></section>;

  return (
    <section ref={ref} className="assembly-scene" id="assembly">
      <div className="assembly-sticky">
        <div className="assembly-grid" />
        <motion.div className="assembly-intro" style={{ opacity: introOpacity }}><span className="eyebrow">SCROLL / ASSEMBLE THE SYSTEM</span><h2>Stop memorizing parts.<br />Start seeing the circuit.</h2><p>Four separate ideas become one plan you can explain.</p><ArrowDown size={20} /></motion.div>
        <motion.div className="assembly-ring" style={{ rotate: ringRotate }}><span /><span /><span /><span /></motion.div>
        <motion.div className="assembly-final" style={{ opacity: finalOpacity, scale: finalScale }}><span className="eyebrow">THE SWITCHCRAFT METHOD</span><h2>ONE CONNECTED PLAN.</h2><p>Your configuration drives every drawing, step and part quantity.</p><a href="#studio" className="text-link">Build yours<ArrowDown size={15} /></a></motion.div>
        {MODULES.map((module, index) => <AssemblyModule key={module.id} module={module} index={index} progress={scrollYProgress} position={positions[index]} />)}
        <div className="assembly-progress"><span style={{ transform: "none" }} /><motion.i style={{ scaleX: progressScale }} /></div>
      </div>
    </section>
  );
}

function AssemblyModule({ module, index, progress, position }: { module: (typeof MODULES)[number]; index: number; progress: MotionValue<number>; position: { x: string[]; y: string[]; rotate: number[] } }) {
  const x = useTransform(progress, [0.08, 0.72], position.x);
  const y = useTransform(progress, [0.08, 0.72], position.y);
  const rotate = useTransform(progress, [0.08, 0.72], position.rotate);
  const scale = useTransform(progress, [0.08, 0.58, 0.85], [1.08, 0.9, 0.74]);
  const opacity = useTransform(progress, [0, 0.12, 0.72, 0.88], [0.5, 1, 1, 0]);
  return <motion.article className={`assembly-module module-${module.id}`} style={{ x, y, rotate, scale, opacity, borderColor: module.color }}><div className="module-icon" style={{ color: module.color }}><module.icon size={25} /></div><span>{module.subtitle}</span><h3>{module.title}</h3><p>{module.copy}</p><div className="module-index">0{index + 1}</div></motion.article>;
}
