"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Check, Download, ExternalLink, Infinity, LockKeyhole, Minus, Package, Play, ShieldCheck, Smartphone, Sparkles, X } from "lucide-react";
import type { SessionPayload } from "@/lib/api-types";
import { Modal, SectionHeading } from "./ui";

interface MembershipProps {
  member: SessionPayload["member"] | null;
  notify: (message: string, kind?: "success" | "error" | "info") => void;
  compact?: boolean;
}

const COMPARISON = [
  { feature: "2/4/6/8-pump system overviews", trial: true, member: true },
  { feature: "2- and 4-pump power, plumbing & switch details", trial: true, member: true },
  { feature: "6- and 8-pump paired-circuit workshops", trial: false, member: true },
  { feature: "2- and 4-switch Wire Lab", trial: true, member: true },
  { feature: "6- and 10-switch construction + continuity matrix", trial: false, member: true },
  { feature: "7 foundation and street lessons", trial: true, member: true },
  { feature: "All 12 lessons + advanced shop notebook", trial: false, member: true },
  { feature: "Saved builds, exports & multi-vendor order board", trial: true, member: true },
];

export function MembershipOptions({ member, notify, compact = false }: MembershipProps) {
  const [busy, setBusy] = useState<"monthly" | "yearly" | null>(null);
  const [installEvent, setInstallEvent] = useState<(Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> }) | null>(null);
  const [installHelp, setInstallHelp] = useState(false);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    const beforeInstall = (event: Event) => {
      event.preventDefault();
      setInstallEvent(event as typeof installEvent);
    };
    const onInstalled = () => { setInstalled(true); setInstallEvent(null); };
    window.addEventListener("beforeinstallprompt", beforeInstall);
    window.addEventListener("appinstalled", onInstalled);
    if (window.matchMedia("(display-mode: standalone)").matches) setInstalled(true);
    return () => { window.removeEventListener("beforeinstallprompt", beforeInstall); window.removeEventListener("appinstalled", onInstalled); };
  }, []);

  const checkout = async (interval: "monthly" | "yearly") => {
    setBusy(interval);
    try {
      const response = await fetch("/api/membership/checkout", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ interval }) });
      const data = await response.json() as { url?: string; error?: string };
      if (!response.ok || !data.url) throw new Error(data.error || "Checkout could not be started.");
      window.location.assign(data.url);
    } catch (error) { notify(error instanceof Error ? error.message : "Checkout could not be started. No charge was made.", "error"); }
    finally { setBusy(null); }
  };

  const install = async () => {
    if (!installEvent) { setInstallHelp(true); return; }
    await installEvent.prompt();
    const choice = await installEvent.userChoice;
    if (choice.outcome === "accepted") notify("Switchcraft installation accepted by your browser.", "success");
    setInstallEvent(null);
  };

  return (
    <div className={`membership-options ${compact ? "compact" : ""}`}>
      <div className="membership-status-card">
        <div className={`status-orb ${member?.status ?? "trial"}`}><ShieldCheck size={25} /></div>
        <div><span className="eyebrow">YOUR ACCESS</span><h3>{!member ? "Starting your workshop…" : member.status === "active" ? "Full membership active" : member.status === "trial" ? `${member.daysLeft} trial day${member.daysLeft === 1 ? "" : "s"} remaining` : "Five-day trial ended"}</h3><p>{member?.status === "active" ? "All current workshops, diagrams and lessons are open on this session." : member?.status === "expired" ? "System overviews, free safety lessons and the vendor catalog remain available. No automatic charge was created." : "The five-day trial begins on your first visit. It includes core 2/4-pump learning, while advanced workshops stay reserved for members."}</p></div>
      </div>
      <div className="comparison-table"><div className="comparison-row comparison-head"><span>Workshop feature</span><strong>5-day trial</strong><strong>Member</strong></div>{COMPARISON.map((row) => <div className="comparison-row" key={row.feature}><span>{row.feature}</span><span>{row.trial ? <Check size={15} /> : <Minus size={15} />}</span><span>{row.member ? <Check size={15} /> : <X size={15} />}</span></div>)}</div>
      {member?.status !== "active" && <div className="pricing-grid">
        <article><span className="eyebrow">MONTHLY WORKSHOP</span><div className="price"><strong>$9</strong><span>/ month</span></div><p>For one project at a time. Cancel through your payment provider according to your subscription terms.</p><button className="button button-outline" disabled={busy !== null} onClick={() => checkout("monthly")}>{busy === "monthly" ? "Opening secure checkout…" : "Choose monthly"}<ArrowRight size={16} /></button></article>
        <article className="recommended"><span className="recommend-tag">BEST FOR A FULL BUILD</span><span className="eyebrow">YEARLY WORKSHOP</span><div className="price"><strong>$79</strong><span>/ year</span></div><p>Keep every lesson, advanced diagram and future workshop update available throughout the build.</p><button className="button button-acid" disabled={busy !== null} onClick={() => checkout("yearly")}>{busy === "yearly" ? "Opening secure checkout…" : "Choose yearly"}<ArrowRight size={16} /></button></article>
      </div>}
      {member?.status !== "active" && <p className="checkout-note"><LockKeyhole size={14} />Checkout uses Stripe when configured by the site operator. You will review the actual price there before paying. If checkout is unavailable, Switchcraft reports it and makes no charge.</p>}

      {!compact && <div className="app-install-panel">
        <div><span className="eyebrow">TAKE IT TO THE GARAGE</span><h3>Install the app. Keep the diagrams close.</h3><p>Switchcraft is an installable Progressive Web App with an offline app shell. Your saved workshop data still needs a connection to sync.</p><button className="button button-dark" onClick={install}>{installed ? <Check size={17} /> : <Download size={17} />}{installed ? "App installed" : installEvent ? "Install Switchcraft" : "How to install"}</button></div>
        <div className="play-roadmap"><span><Play size={16} />GOOGLE PLAY RELEASE PATH</span><ol><li><strong>Ready now</strong>Installable PWA shell</li><li><strong>Release step</strong>Sign a Trusted Web Activity Android bundle</li><li><strong>Required</strong>Developer account, digital asset links and closed testing</li><li><strong>Not claimed</strong>This preview is not yet listed on Google Play</li></ol></div>
      </div>}

      <Modal open={installHelp} onClose={() => setInstallHelp(false)} title="Install Switchcraft" eyebrow="NO APP STORE REQUIRED FOR THE WEB APP">
        <div className="install-instructions"><section><Smartphone size={21} /><div><h4>Android / Chrome</h4><p>Open the browser menu, then choose “Install app” or “Add to Home screen.” If Chrome offers a native install prompt, the button in the main page can launch it directly.</p></div></section><section><Smartphone size={21} /><div><h4>iPhone / Safari</h4><p>Tap Share, then “Add to Home Screen.” The installed icon opens Switchcraft in its own app-style window.</p></div></section><section><ExternalLink size={21} /><div><h4>Google Play</h4><p>A Play Store listing requires a signed Android package, a verified domain association and a publisher account. Those publishing credentials are not available in this preview, so no listing is being faked.</p></div></section></div>
      </Modal>
    </div>
  );
}

export default function MembershipSection({ member, notify }: MembershipProps) {
  return (
    <section id="membership" className="membership-section section-pad">
      <div className="page-shell">
        <SectionHeading number="05" eyebrow="MEMBERSHIP + APP" title="Learn free. Build deeper when you’re ready." copy="The five-day trial is genuinely limited: core two- and four-pump skills are open, while paired-pump and advanced switch-box workshops require membership. There is no automatic checkout hidden at the end." light />
        <MembershipOptions member={member} notify={notify} />
        <div className="supply-roadmap"><div><span className="eyebrow">WHERE PARTS SALES CAN GO</span><h3>Start useful before starting a warehouse.</h3><p>The supplier desk creates value now without pretending Switchcraft owns inventory. A future store should be earned by reliable fulfillment, not launched as an empty badge.</p></div><div className="roadmap-steps"><article><span>01 · NOW</span><StoreIcon /><h4>Multi-vendor desk</h4><p>Real supplier listings, build matching and saved order boards. Vendors fulfill and take payment.</p></article><article><span>02 · WITH REVENUE</span><Sparkles size={21} /><h4>Member sourcing benefits</h4><p>Negotiated supplier discounts, fitment review and better availability feeds where partners permit them.</p></article><article><span>03 · WHEN EARNED</span><Package size={21} /><h4>Switchcraft Supply</h4><p>Stock the small essentials builders repeatedly need—cord, labels, terminals and service kits—with real inventory and support.</p></article></div></div>
        <div className="membership-faq"><details><summary>Does the trial automatically become a paid plan?<PlusIcon /></summary><p>No. This implementation starts a five-day access window, not a payment subscription. A paid plan begins only after you intentionally complete a configured Stripe Checkout.</p></details><details><summary>Why are 6- and 8-pump overviews visible but details locked?<PlusIcon /></summary><p>The overview lets you compare system families before choosing a plan. Detailed high-energy power, paired plumbing and advanced combination wiring are part of the paid workshop.</p></details><details><summary>Can I use the app without a shop?<PlusIcon /></summary><p>Yes for measurement, bench wiring, planning and learning. Structural welding, pressurized service and any task outside your skill or equipment should go to a qualified professional. Saving shop labor should never mean skipping safety.</p></details><details><summary>Are vendor prices and stock guaranteed?<PlusIcon /></summary><p>No. Catalog prices are reference snapshots and stock is not represented as live. The supplier’s current listing and checkout control the final order.</p></details></div>
      </div>
    </section>
  );
}

function PlusIcon() { return <span aria-hidden="true">+</span>; }
function StoreIcon() { return <Infinity size={21} />; }
