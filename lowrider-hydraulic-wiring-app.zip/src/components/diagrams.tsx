"use client";

import type { BuildConfig, Circuit, HydraulicCommand, SwitchBoxSize } from "@/lib/hydraulics";
import { getBatteryPlan, getBoxCommands, getCircuits, getSwitchSpec, getWireMap, WIRE_COLORS } from "@/lib/hydraulics";

const CORNER_HEX = { FL: "#ff963f", FR: "#f7d54d", RL: "#42db8b", RR: "#4aa8ff" };
const CORNER_POSITION = { FL: { x: 405, y: 165 }, FR: { x: 795, y: 165 }, RL: { x: 405, y: 405 }, RR: { x: 795, y: 405 } };

function PumpGlyph({ x, y, id, active = false, color = "#d9ff43" }: { x: number; y: number; id: number; active?: boolean; color?: string }) {
  return (
    <g className={active ? "diagram-pump is-active" : "diagram-pump"} transform={`translate(${x} ${y})`}>
      <rect width="64" height="40" rx="7" fill={active ? color : "#202822"} stroke={active ? color : "#657066"} strokeWidth="1.5" />
      <circle cx="18" cy="20" r="10" fill="none" stroke={active ? "#10130f" : "#a7b0a5"} strokeWidth="2" />
      <path d="M32 11h23M32 20h23M32 29h23" stroke={active ? "#10130f" : "#a7b0a5"} strokeWidth="2" />
      <text x="32" y="55" textAnchor="middle" className="diagram-label">PUMP {id}</text>
    </g>
  );
}

function CylinderGlyph({ x, y, corner, active }: { x: number; y: number; corner: keyof typeof CORNER_HEX; active: boolean }) {
  return (
    <g className={active ? "diagram-cylinder is-active" : "diagram-cylinder"} transform={`translate(${x} ${y})`}>
      <rect x="-24" y="-18" width="48" height="36" rx="8" fill="#171d19" stroke={CORNER_HEX[corner]} strokeWidth={active ? 3 : 1.5} />
      <path className="cylinder-ram" d="M0-18V-38" stroke={CORNER_HEX[corner]} strokeWidth="6" strokeLinecap="round" />
      <circle r="7" fill={CORNER_HEX[corner]} opacity={active ? 1 : 0.45} />
      <text y="35" textAnchor="middle" fill={CORNER_HEX[corner]} className="diagram-corner">{corner}</text>
    </g>
  );
}

export interface ActiveTest {
  command: HydraulicCommand;
  direction: "up" | "down";
}

export function SystemDiagram({ config, activeTest }: { config: BuildConfig; activeTest: ActiveTest | null }) {
  const circuits = getCircuits(config);
  const battery = getBatteryPlan(config);
  const pumpPositions = Array.from({ length: config.pumpCount }, (_, index) => {
    const columns = config.pumpCount <= 4 ? config.pumpCount : Math.ceil(config.pumpCount / 2);
    const rows = Math.ceil(config.pumpCount / columns);
    const row = Math.floor(index / columns);
    const inRow = index % columns;
    const countInRow = row === rows - 1 ? config.pumpCount - row * columns : columns;
    const startX = 600 - (countInRow * 88) / 2;
    return { x: startX + inRow * 88, y: rows === 1 ? 492 : 465 + row * 67 };
  });
  const isCombo = activeTest?.command.id === "seesaw";
  const activePumps = activeTest && (activeTest.direction === "up" || isCombo) ? activeTest.command.upPumpIds : [];
  const activeDumps = activeTest && (activeTest.direction === "down" || isCombo) ? activeTest.command.downDumpIds : [];
  const pumpCircuit = new Map<number, Circuit>();
  circuits.forEach((circuit) => circuit.pumpIds.forEach((id) => pumpCircuit.set(id, circuit)));
  const dumpPosition = (circuit: Circuit) => {
    const corner = CORNER_POSITION[circuit.id];
    if (!circuit.sharedDump) return { x: corner.x + (circuit.id.endsWith("L") ? 55 : -55), y: corner.y + 25 };
    return { x: 600, y: circuit.id.startsWith("F") ? 215 : 385 };
  };

  return (
    <svg id="system-diagram" viewBox="0 0 1000 610" className="technical-svg" role="img" aria-labelledby="system-title system-desc">
      <title id="system-title">{config.pumpCount}-pump system overview for {config.vehicleYear} {config.vehicleMake} {config.vehicleModel}</title>
      <desc id="system-desc">Color-coded hydraulic circuits from trunk pumps to four corner cylinders, with battery bank, switch box, dumps and active test highlighting.</desc>
      <defs>
        <pattern id="overview-grid" width="25" height="25" patternUnits="userSpaceOnUse"><path d="M25 0H0V25" fill="none" stroke="#29312b" strokeWidth="0.7" /></pattern>
        <filter id="active-glow"><feGaussianBlur stdDeviation="4" result="blur" /><feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge></filter>
      </defs>
      <rect width="1000" height="610" fill="#101411" />
      <rect width="1000" height="610" fill="url(#overview-grid)" />
      <text x="28" y="32" className="diagram-eyebrow">LIVE SYSTEM MAP · TOP VIEW</text>
      <text x="972" y="32" textAnchor="end" className="diagram-eyebrow">{config.pumpCount} PUMPS / {new Set(circuits.map((c) => c.dumpId)).size} DUMPS</text>

      <g transform="translate(35 78)">
        <rect width="245" height="408" rx="18" fill="#141a16" stroke="#3b463e" />
        <text x="20" y="30" className="diagram-section">POWER RACK</text>
        <text x="20" y="52" className="diagram-copy">{battery.series}S × {battery.strings}P · {config.motorVoltage}V BUS</text>
        {Array.from({ length: Math.min(config.batteryCount, 12) }, (_, index) => {
          const columns = Math.ceil(Math.min(config.batteryCount, 12) / 2);
          const col = index % columns;
          const row = Math.floor(index / columns);
          return <g key={index} transform={`translate(${20 + col * 31} ${76 + row * 58})`}><rect width="24" height="39" rx="3" fill="#242d26" stroke="#778177" /><path d="M5 0v-5h5v5M15 0v-5h5v5" stroke="#778177" /><text x="12" y="25" textAnchor="middle" className="diagram-micro">12V</text></g>;
        })}
        {config.batteryCount > 12 && <text x="20" y="310" className="diagram-copy">+ {config.batteryCount - 12} more in matched strings</text>}
        <path d="M20 372H225" stroke="#3b463e" />
        <text x="20" y="393" className="diagram-copy">{config.controlVoltage}V fused control supply</text>
      </g>

      <path d="M280 280H322V110H455" fill="none" stroke={WIRE_COLORS.red} strokeWidth="2" strokeDasharray="5 5" />
      <text x="290" y="267" className="diagram-micro" fill={WIRE_COLORS.red}>CONTROL</text>

      <g>
        <path d="M355 88Q355 55 395 55H805Q845 55 845 88L875 470Q878 545 815 560H385Q322 545 325 470Z" fill="#151b17" stroke="#59645b" strokeWidth="2" />
        <path d="M410 105H790L815 245H385Z" fill="#1d2620" stroke="#3d4940" />
        <path d="M390 330H810L825 450H375Z" fill="#1d2620" stroke="#3d4940" />
        <path d="M600 56V560" stroke="#2f3932" strokeDasharray="4 8" />
        <text x="600" y="88" textAnchor="middle" className="diagram-micro">FRONT</text>
        <text x="600" y="580" textAnchor="middle" className="diagram-micro">TRUNK / PUMP RACK</text>
      </g>

      <g transform="translate(505 88)">
        <rect width="190" height="50" rx="8" fill="#d9ff43" />
        <text x="95" y="22" textAnchor="middle" fill="#11150f" className="diagram-section">SWITCH BOX</text>
        <text x="95" y="39" textAnchor="middle" fill="#11150f" className="diagram-micro">{config.switchBox} SWITCHES · MOMENTARY</text>
      </g>

      {circuits.map((circuit) => circuit.pumpIds.map((pumpId) => {
        const position = pumpPositions[pumpId - 1];
        const target = CORNER_POSITION[circuit.id];
        const active = activePumps.includes(pumpId);
        return <path key={`${circuit.id}-${pumpId}`} d={`M${position.x + 32} ${position.y} C${position.x + 32} ${position.y - 85}, ${target.x} ${target.y + 115}, ${target.x} ${target.y}`} fill="none" stroke={CORNER_HEX[circuit.id]} strokeWidth={active ? 5 : 2} opacity={active ? 1 : 0.38} className={active ? "oil-flow" : ""} filter={active ? "url(#active-glow)" : undefined} />;
      }))}

      {circuits.map((circuit, index) => {
        const position = dumpPosition(circuit);
        const previous = circuits.slice(0, index).find((entry) => entry.dumpId === circuit.dumpId);
        if (previous) return null;
        const active = activeDumps.includes(circuit.dumpId);
        return <g key={circuit.dumpId} transform={`translate(${position.x} ${position.y})`}><rect x="-15" y="-12" width="30" height="24" rx="5" fill={active ? CORNER_HEX[circuit.id] : "#1a211c"} stroke={CORNER_HEX[circuit.id]} /><text y="4" textAnchor="middle" fill={active ? "#11150f" : CORNER_HEX[circuit.id]} className="diagram-micro">{circuit.dumpId}</text></g>;
      })}

      {circuits.map((circuit) => {
        const position = CORNER_POSITION[circuit.id];
        const active = activePumps.some((id) => circuit.pumpIds.includes(id)) || activeDumps.includes(circuit.dumpId);
        return <CylinderGlyph key={circuit.id} x={position.x} y={position.y} corner={circuit.id} active={active} />;
      })}
      {pumpPositions.map((position, index) => {
        const circuit = pumpCircuit.get(index + 1)!;
        return <PumpGlyph key={index} {...position} id={index + 1} active={activePumps.includes(index + 1)} color={CORNER_HEX[circuit.id]} />;
      })}

      <g transform="translate(35 525)">
        <text className="diagram-section">TEST LEGEND</text>
        <circle cx="8" cy="25" r="5" fill="#d9ff43" /><text x="22" y="29" className="diagram-copy">Bright + moving dash = energized in test</text>
        <text y="52" className="diagram-copy">Simulation only · no hardware is connected</text>
      </g>
    </svg>
  );
}

export function PowerDiagram({ config }: { config: BuildConfig }) {
  const battery = getBatteryPlan(config);
  const circuits = getCircuits(config);
  const wireMap = getWireMap(config);
  const solenoidCount = config.tier === "backyard" ? 2 : 3;
  const rowHeight = Math.max(58, 440 / config.pumpCount);
  const pumpTrigger = (pumpId: number) => {
    const circuit = circuits.find((entry) => entry.pumpIds.includes(pumpId))!;
    if (config.pumpCount === 2) return circuit.id.startsWith("F") ? wireMap.find((wire) => wire.id === "P-F")! : wireMap.find((wire) => wire.id === "P-R")!;
    return wireMap.find((wire) => wire.id === `P-${circuit.id}`)!;
  };
  const height = Math.max(650, 120 + config.pumpCount * rowHeight);
  const visibleStrings = Math.min(battery.strings, 6);
  const stringGap = Math.min(82, 420 / Math.max(visibleStrings, 1));

  return (
    <svg id="power-diagram" viewBox={`0 0 1100 ${height}`} className="technical-svg" role="img" aria-labelledby="power-title power-desc">
      <title id="power-title">Battery and solenoid power diagram</title>
      <desc id="power-desc">{battery.strings} parallel strings of {battery.series} batteries feeding {config.pumpCount} motors through solenoid banks.</desc>
      <defs><pattern id="power-grid" width="25" height="25" patternUnits="userSpaceOnUse"><path d="M25 0H0V25" fill="none" stroke="#29312b" strokeWidth="0.7" /></pattern></defs>
      <rect width="1100" height={height} fill="#101411" /><rect width="1100" height={height} fill="url(#power-grid)" />
      <text x="28" y="32" className="diagram-eyebrow">HIGH-CURRENT POWER · NOT TO SCALE</text>
      <text x="1070" y="32" textAnchor="end" className="diagram-eyebrow">VERIFY ALL COMPONENT RATINGS</text>
      <text x="35" y="76" className="diagram-section">BATTERY BANK · {battery.series}S {battery.strings}P</text>
      <text x="520" y="76" className="diagram-section">SOLENOID BANKS + MOTORS</text>

      {Array.from({ length: visibleStrings }, (_, stringIndex) => {
        const y = 115 + stringIndex * stringGap;
        const batteryWidth = Math.min(45, 275 / battery.series);
        return <g key={stringIndex}>
          <text x="35" y={y + 24} className="diagram-micro">STRING {stringIndex + 1}</text>
          {Array.from({ length: battery.series }, (_, batteryIndex) => {
            const x = 95 + batteryIndex * batteryWidth;
            return <g key={batteryIndex} transform={`translate(${x} ${y})`}>
              <rect width={batteryWidth - 7} height="40" rx="4" fill="#202822" stroke="#758176" />
              <text x="4" y="-5" className="diagram-micro">−</text><text x={batteryWidth - 13} y="-5" className="diagram-micro" fill={WIRE_COLORS.red}>+</text>
              <text x={(batteryWidth - 7) / 2} y="25" textAnchor="middle" className="diagram-micro">B{batteryIndex + 1}</text>
              {batteryIndex < battery.series - 1 && <path d={`M${batteryWidth - 7} 8H${batteryWidth + 3}V32H${batteryWidth}`} fill="none" stroke={WIRE_COLORS.red} strokeWidth="2" />}
              {batteryIndex === battery.controlBatteries - 1 && <path d={`M${batteryWidth - 7} 20H405`} fill="none" stroke={WIRE_COLORS.red} strokeWidth="1.5" strokeDasharray="4 3" />}
            </g>;
          })}
          <path d={`M${95 + battery.series * batteryWidth - 7} ${y + 20}H435V560`} fill="none" stroke={WIRE_COLORS.red} strokeWidth="3" />
          <path d={`M92 ${y + 20}H65V575`} fill="none" stroke="#87919e" strokeWidth="3" />
        </g>;
      })}
      {battery.strings > visibleStrings && <text x="35" y={125 + visibleStrings * stringGap} className="diagram-copy">+ {battery.strings - visibleStrings} identical strings · same bus connections</text>}
      <path d="M405 105V560" stroke={WIRE_COLORS.red} strokeWidth="1.5" strokeDasharray="4 3" />
      <text x="397" y="98" textAnchor="end" className="diagram-micro" fill={WIRE_COLORS.red}>{config.controlVoltage}V CONTROL BUS</text>
      <text x="447" y="552" className="diagram-micro" fill={WIRE_COLORS.red}>+ MOTOR BUS</text>
      <text x="55" y="596" className="diagram-micro">COMMON NEGATIVE / GROUND</text>

      {Array.from({ length: config.pumpCount }, (_, index) => {
        const y = 112 + index * rowHeight;
        const trigger = pumpTrigger(index + 1);
        const motorX = 1000;
        return <g key={index}>
          <text x="520" y={y - 9} className="diagram-micro" fill={trigger.color}>P{index + 1} · {trigger.colorName.toUpperCase()} TRIGGER</text>
          <path d={`M435 560V${y + 18}H545`} fill="none" stroke={WIRE_COLORS.red} strokeWidth="3" opacity="0.75" />
          {Array.from({ length: solenoidCount }, (_, solenoidIndex) => {
            const x = 550 + solenoidIndex * 88;
            return <g key={solenoidIndex} transform={`translate(${x} ${y})`}>
              <rect width="62" height="40" rx="6" fill="#202822" stroke="#7b867b" />
              <circle cx="8" cy="8" r="3" fill={WIRE_COLORS.red} /><circle cx="54" cy="8" r="3" fill="#ff963f" />
              <circle cx="31" cy="-5" r="4" fill={trigger.color} /><text x="31" y="27" textAnchor="middle" className="diagram-micro">SOL</text>
              <text x="31" y="53" textAnchor="middle" className="diagram-micro">S{solenoidIndex + 1}</text>
              {solenoidIndex < solenoidCount - 1 && <><path d="M8 8H96" stroke={WIRE_COLORS.red} strokeWidth="3" /><path d="M54 8H142" stroke="#ff963f" strokeWidth="3" /><path d="M31-5H119" stroke={trigger.color} strokeWidth="1.5" /></>}
            </g>;
          })}
          <path d={`M405 ${Math.min(y + 10, 550)}H520V${y - 5}H${550}`} fill="none" stroke={trigger.color} strokeWidth="1.5" />
          <path d={`M${550 + (solenoidCount - 1) * 88 + 54} ${y + 8}H${motorX - 15}`} stroke="#ff963f" strokeWidth="3" />
          <g transform={`translate(${motorX} ${y + 20})`}><circle r="27" fill="#202822" stroke={trigger.color} strokeWidth="2" /><text y="5" textAnchor="middle" className="diagram-section">M{index + 1}</text></g>
          <path d={`M${motorX} ${y + 47}V${y + 58}H65`} fill="none" stroke="#87919e" strokeWidth="1.5" opacity="0.5" />
        </g>;
      })}
      <g transform={`translate(35 ${height - 38})`}><text className="diagram-copy">THICK RED = motor positive · GRAY = negative/ground · COLORED THIN = switch trigger · S posts are trigger contacts</text></g>
    </svg>
  );
}

export function PlumbingDiagram({ config, activeTest }: { config: BuildConfig; activeTest: ActiveTest | null }) {
  const circuits = getCircuits(config);
  const isCombo = activeTest?.command.id === "seesaw";
  const activePumps = activeTest && (activeTest.direction === "up" || isCombo) ? activeTest.command.upPumpIds : [];
  const activeDumps = activeTest && (activeTest.direction === "down" || isCombo) ? activeTest.command.downDumpIds : [];
  const twoPump = config.pumpCount === 2;

  return (
    <svg id="plumbing-diagram" viewBox="0 0 1000 620" className="technical-svg" role="img" aria-labelledby="plumb-title plumb-desc">
      <title id="plumb-title">Hydraulic plumbing diagram</title>
      <desc id="plumb-desc">Pump pressure outlets, individual check valves, junctions, corner dumps, optional accumulators and four cylinders.</desc>
      <defs><pattern id="plumb-grid" width="25" height="25" patternUnits="userSpaceOnUse"><path d="M25 0H0V25" fill="none" stroke="#29312b" strokeWidth="0.7" /></pattern><marker id="arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M0 0L10 5L0 10Z" fill="context-stroke" /></marker></defs>
      <rect width="1000" height="620" fill="#101411" /><rect width="1000" height="620" fill="url(#plumb-grid)" />
      <text x="28" y="32" className="diagram-eyebrow">PRESSURE + RETURN LOGIC · ONE-WAY CHECKS</text>
      <text x="28" y="64" className="diagram-copy">Solid line = pressure circuit · dotted return path at dump · check valve points toward cylinder</text>

      {twoPump ? <>
        {[1, 2].map((pumpId) => {
          const front = pumpId === 1;
          const y = front ? 190 : 450;
          const ownCircuits = circuits.filter((circuit) => circuit.pumpIds.includes(pumpId));
          const active = activePumps.includes(pumpId);
          return <g key={pumpId}>
            <PumpGlyph x={65} y={y - 20} id={pumpId} active={active} color={front ? CORNER_HEX.FL : CORNER_HEX.RL} />
            <path d={`M129 ${y}H245`} stroke={front ? CORNER_HEX.FL : CORNER_HEX.RL} strokeWidth={active ? 5 : 3} className={active ? "oil-flow" : ""} />
            <g transform={`translate(260 ${y})`}><path d="M-12-12L12 0L-12 12Z" fill="none" stroke="#f4f2ea" strokeWidth="2" /><path d="M14-14V14" stroke="#f4f2ea" strokeWidth="2" /><text y="32" textAnchor="middle" className="diagram-micro">CHECK</text></g>
            <path d={`M275 ${y}H400`} stroke={front ? CORNER_HEX.FL : CORNER_HEX.RL} strokeWidth="3" markerEnd="url(#arrow)" />
            {ownCircuits.map((circuit) => {
              const targetY = circuit.id === "FL" ? 120 : circuit.id === "FR" ? 250 : circuit.id === "RL" ? 390 : 520;
              return <g key={circuit.id}>
                <path d={`M400 ${y}V${targetY}H785`} fill="none" stroke={CORNER_HEX[circuit.id]} strokeWidth={active ? 5 : 2.5} opacity={active ? 1 : 0.65} className={active ? "oil-flow" : ""} />
                <circle cx="400" cy={targetY} r="5" fill={CORNER_HEX[circuit.id]} />
                <g transform={`translate(835 ${targetY})`}><rect x="-30" y="-18" width="60" height="36" rx="8" fill="#1c241e" stroke={CORNER_HEX[circuit.id]} strokeWidth="2" /><text y="5" textAnchor="middle" className="diagram-section" fill={CORNER_HEX[circuit.id]}>{circuit.id} CYL</text></g>
              </g>;
            })}
          </g>;
        })}
        {circuits.map((circuit, index) => {
          const previous = circuits.slice(0, index).find((entry) => entry.dumpId === circuit.dumpId);
          if (previous) return null;
          const targetY = circuit.sharedDump ? (circuit.id.startsWith("F") ? 185 : 455) : circuit.id === "FL" ? 120 : circuit.id === "FR" ? 250 : circuit.id === "RL" ? 390 : 520;
          const active = activeDumps.includes(circuit.dumpId);
          return <g key={circuit.dumpId} transform={`translate(640 ${targetY})`}><rect x="-25" y="-18" width="50" height="36" rx="6" fill={active ? CORNER_HEX[circuit.id] : "#1b231d"} stroke={CORNER_HEX[circuit.id]} /><text y="4" textAnchor="middle" className="diagram-micro" fill={active ? "#11150f" : CORNER_HEX[circuit.id]}>{circuit.dumpId}</text><path d="M0 18V45H-260" fill="none" stroke={CORNER_HEX[circuit.id]} strokeDasharray="4 5" opacity="0.6" /></g>;
        })}
      </> : circuits.map((circuit, circuitIndex) => {
        const y = 115 + circuitIndex * 130;
        return <g key={circuit.id}>
          <text x="30" y={y - 45} className="diagram-section" fill={CORNER_HEX[circuit.id]}>{circuit.id} · {circuit.name.toUpperCase()}</text>
          {circuit.pumpIds.map((pumpId, pumpIndex) => {
            const x = circuit.pumpIds.length === 1 ? 90 : 45 + pumpIndex * 110;
            const active = activePumps.includes(pumpId);
            return <g key={pumpId}>
              <PumpGlyph x={x} y={y - 20} id={pumpId} active={active} color={CORNER_HEX[circuit.id]} />
              <path d={`M${x + 64} ${y}H245`} stroke={CORNER_HEX[circuit.id]} strokeWidth={active ? 5 : 2.5} className={active ? "oil-flow" : ""} />
              <g transform={`translate(260 ${y})`}><path d="M-12-12L12 0L-12 12Z" fill="none" stroke="#f4f2ea" strokeWidth="2" /><path d="M14-14V14" stroke="#f4f2ea" strokeWidth="2" /></g>
              <path d={`M275 ${y}H430`} stroke={CORNER_HEX[circuit.id]} strokeWidth={active ? 5 : 2.5} className={active ? "oil-flow" : ""} />
            </g>;
          })}
          <circle cx="430" cy={y} r="7" fill={CORNER_HEX[circuit.id]} /><text x="430" y={y + 25} textAnchor="middle" className="diagram-micro">JOIN AFTER CHECKS</text>
          <path d={`M430 ${y}H805`} stroke={CORNER_HEX[circuit.id]} strokeWidth={activePumps.some((id) => circuit.pumpIds.includes(id)) ? 5 : 3} className={activePumps.some((id) => circuit.pumpIds.includes(id)) ? "oil-flow" : ""} markerEnd="url(#arrow)" />
          <g transform={`translate(650 ${y})`}><rect x="-27" y="-18" width="54" height="36" rx="6" fill={activeDumps.includes(circuit.dumpId) ? CORNER_HEX[circuit.id] : "#1b231d"} stroke={CORNER_HEX[circuit.id]} /><text y="4" textAnchor="middle" className="diagram-micro">{circuit.dumpId}</text><path d="M0 18V45H-220" fill="none" stroke={CORNER_HEX[circuit.id]} strokeDasharray="4 5" opacity="0.6" /></g>
          {config.accumulators && <g transform={`translate(745 ${y - 35})`}><circle r="18" fill="#1b231d" stroke="#f4f2ea" /><path d="M0 18V35" stroke="#f4f2ea" /><text y="4" textAnchor="middle" className="diagram-micro">N₂</text></g>}
          <g transform={`translate(855 ${y})`}><rect x="-38" y="-22" width="76" height="44" rx="8" fill="#1c241e" stroke={CORNER_HEX[circuit.id]} strokeWidth="2" /><text y="5" textAnchor="middle" className="diagram-section" fill={CORNER_HEX[circuit.id]}>{circuit.id} CYL</text></g>
        </g>;
      })}
      <text x="28" y="600" className="diagram-copy">Use component-specific port maps and rated fittings. This is circuit logic, not a machining or thread-size drawing.</text>
    </svg>
  );
}

export function SwitchBoxDiagram({ config, size = config.switchBox, step = 5, onTerminal, diagramId = "switchbox-diagram" }: { config: BuildConfig; size?: SwitchBoxSize; step?: number; onTerminal?: (message: string) => void; diagramId?: string }) {
  const commands = getBoxCommands(config, size);
  const columns = size === 2 ? 2 : size === 4 ? 2 : size === 6 ? 3 : 5;
  const cellW = columns === 5 ? 204 : columns === 3 ? 320 : 440;
  const cellH = 245;
  const rows = Math.ceil(commands.length / columns);
  const width = columns * cellW + 40;
  const height = rows * cellH + 105;
  const wires = getWireMap(config);
  const channelWire = (channel: string, kind: "pump" | "dump") => {
    if (kind === "dump") return wires.find((wire) => wire.id === channel);
    const circuit = getCircuits(config).find((entry) => entry.pumpIds.join("+") === channel);
    if (config.pumpCount === 2) return wires.find((wire) => wire.id === (circuit?.id.startsWith("F") ? "P-F" : "P-R"));
    return wires.find((wire) => wire.id === `P-${circuit?.id}`);
  };
  const terminal = (x: number, y: number, color: string | undefined, label: string, enabled: boolean, key: string) => (
    <g key={key} onClick={() => onTerminal?.(label)} className={onTerminal ? "terminal-click" : ""} role={onTerminal ? "button" : undefined} aria-label={onTerminal ? label : undefined}>
      <circle cx={x} cy={y} r="8" fill={enabled && color ? color : "#252e27"} stroke={enabled && color ? color : "#859085"} strokeWidth="2" />
      <circle cx={x} cy={y} r="2.5" fill="#0e120f" />
      <title>{label}</title>
    </g>
  );

  return (
    <svg id={diagramId} viewBox={`0 0 ${width} ${height}`} className="technical-svg switchbox-svg" role="img" aria-labelledby={`${diagramId}-title ${diagramId}-desc`}>
      <title id={`${diagramId}-title`}>{size}-switch box wiring diagram</title>
      <desc id={`${diagramId}-desc`}>Wiring-side view with locating notches up. Red commons, colored pump raise contacts and dump lower contacts are highlighted according to the current lesson step.</desc>
      <defs><pattern id="switch-grid" width="25" height="25" patternUnits="userSpaceOnUse"><path d="M25 0H0V25" fill="none" stroke="#29312b" strokeWidth="0.7" /></pattern></defs>
      <rect width={width} height={height} fill="#101411" /><rect width={width} height={height} fill="url(#switch-grid)" />
      <text x="22" y="28" className="diagram-eyebrow">WIRING SIDE · LOCATING NOTCHES UP · MOMENTARY (ON)-OFF-(ON)</text>
      <text x={width - 22} y="28" textAnchor="end" className="diagram-eyebrow">METER-VERIFY YOUR SWITCH</text>
      {commands.map((command, index) => {
        const col = index % columns;
        const row = Math.floor(index / columns);
        const x = 20 + col * cellW;
        const y = 50 + row * cellH;
        const spec = getSwitchSpec(command);
        const poleGap = spec.poles === 1 ? 0 : Math.min(42, 145 / (spec.poles - 1));
        const center = x + cellW / 2;
        const poleX = (pole: number) => center + (pole - (spec.poles - 1) / 2) * poleGap;
        return <g key={command.id}>
          <rect x={x + 6} y={y} width={cellW - 12} height={cellH - 15} rx="14" fill="#161d18" stroke={step === 1 ? "#d9ff43" : "#455148"} strokeWidth={step === 1 ? 3 : 1.5} />
          <text x={center} y={y + 26} textAnchor="middle" className="diagram-section">{index + 1} · {command.shortLabel}</text>
          <text x={center} y={y + 44} textAnchor="middle" className="diagram-micro">{spec.prongs} PRONG · {spec.type} · {spec.poles} POLE{spec.poles > 1 ? "S" : ""}</text>
          <path d={`M${center - 9} ${y + 66}Q${center} ${y + 48} ${center + 9} ${y + 66}`} fill="none" stroke="#e7ece5" strokeWidth="3" />
          <path d={`M${center} ${y + 61}V${y + 80}`} stroke="#e7ece5" strokeWidth="4" strokeLinecap="round" />
          <path d={`M${center - 5} ${y + 51}L${center} ${y + 45}L${center + 5} ${y + 51}`} fill="none" stroke="#d9ff43" strokeWidth="2" />
          {Array.from({ length: spec.poles }, (_, pole) => {
            const up = command.upChannels[pole];
            const down = command.downChannels[pole];
            const upWire = up ? channelWire(up, "pump") : undefined;
            const downWire = down ? channelWire(down, "dump") : undefined;
            const px = poleX(pole);
            return <g key={pole}>
              <text x={px} y={y + 91} textAnchor="middle" className="diagram-micro">P{pole + 1}</text>
              {terminal(px, y + 108, downWire?.color, `${command.label}, pole ${pole + 1}, top/lower contact: ${downWire?.function ?? "unused"}`, step >= 4, `down-${pole}`)}
              {terminal(px, y + 139, WIRE_COLORS.red, `${command.label}, pole ${pole + 1}, common: fused ${config.controlVoltage}V red control feed`, step >= 2, `common-${pole}`)}
              {terminal(px, y + 170, upWire?.color, `${command.label}, pole ${pole + 1}, bottom/raise contact: ${upWire?.function ?? "unused"}`, step >= 3, `up-${pole}`)}
              <path d={`M${px} ${y + 100}V${y + 82}`} stroke={step >= 4 && downWire ? downWire.color : "#4a554c"} strokeWidth="3" />
              <path d={`M${px} ${y + 178}V${y + 198}`} stroke={step >= 3 && upWire ? upWire.color : "#4a554c"} strokeWidth="3" />
              <path d={`M${px} ${y + 147}V${y + 161}`} stroke={step >= 2 ? WIRE_COLORS.red : "#4a554c"} strokeWidth="2" />
            </g>;
          })}
          <text x={x + 16} y={y + 112} className="diagram-micro">DUMP ↓</text>
          <text x={x + 16} y={y + 143} className="diagram-micro" fill={WIRE_COLORS.red}>COM</text>
          <text x={x + 16} y={y + 174} className="diagram-micro">PUMP ↑</text>
          <text x={center} y={y + 218} textAnchor="middle" className="diagram-micro">{command.upChannels.length} UP CH · {command.downChannels.length} DOWN CH</text>
        </g>;
      })}
      <text x="22" y={height - 20} className="diagram-copy">Handle-side motion can be opposite the closed rear contacts. Top = dump and bottom = pump in THIS wiring-side convention.</text>
    </svg>
  );
}

export function WireColorLegend({ config }: { config: BuildConfig }) {
  const wires = getWireMap(config);
  return (
    <div className="wire-legend">
      {wires.map((wire) => <div className="wire-legend-row" key={wire.id}>
        <span className="wire-swatch" style={{ backgroundColor: wire.color }} />
        <div><strong>{wire.colorName} · {wire.function}</strong><span>{wire.destination}</span></div>
      </div>)}
    </div>
  );
}
