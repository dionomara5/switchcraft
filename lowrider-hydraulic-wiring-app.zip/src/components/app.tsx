"use client";

import { useCallback, useEffect, useState } from "react";
import { AnimatePresence, motion, MotionConfig } from "framer-motion";
import { ArrowUpRight, BookOpen, CircuitBoard, Menu, ShieldAlert, X } from "lucide-react";
import type { BuildConfig } from "@/lib/hydraulics";
import { DEFAULT_CONFIG, normalizeConfig } from "@/lib/hydraulics";
import type { ClientBuild, ClientProgress, ClientShoppingItem, SessionPayload } from "@/lib/api-types";
import Hero from "./hero";
import ScrollScene from "./scroll-scene";
import BuildStudio from "./build-studio";
import WireLab from "./wire-lab";
import Academy from "./academy";
import PartsDesk from "./parts-desk";
import MembershipSection, { MembershipOptions } from "./membership";
import { Modal, Toast } from "./ui";

type ToastState = { message: string; kind?: "success" | "error" | "info" } | null;

export default function SwitchcraftApp() {
  const [config, setConfig] = useState<BuildConfig>(DEFAULT_CONFIG);
  const [session, setSession] = useState<SessionPayload | null>(null);
  const [builds, setBuilds] = useState<ClientBuild[]>([]);
  const [progress, setProgress] = useState<ClientProgress[]>([]);
  const [shopping, setShopping] = useState<ClientShoppingItem[]>([]);
  const [toast, setToast] = useState<ToastState>(null);
  const [membershipOpen, setMembershipOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [draftReady, setDraftReady] = useState(false);
  const notify = useCallback((message: string, kind: "success" | "error" | "info" = "info") => setToast({ message, kind }), []);
  const closeToast = useCallback(() => setToast(null), []);
  const status = session?.member.status ?? "trial";

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const shared = params.get("build");
      if (shared) {
        setConfig(normalizeConfig(JSON.parse(shared) as Partial<BuildConfig>));
        window.setTimeout(() => notify("Shared build loaded. Every view now uses that configuration.", "success"), 600);
      } else {
        const draft = window.localStorage.getItem("switchcraft_draft");
        if (draft) setConfig(normalizeConfig(JSON.parse(draft) as Partial<BuildConfig>));
      }
    } catch { notify("That shared build link was not readable. The default plan is open instead.", "error"); }
    setDraftReady(true);

    fetch("/api/session", { method: "POST" }).then(async (response) => {
      const data = await response.json() as SessionPayload & { error?: string };
      if (!response.ok) throw new Error(data.error || "Workshop session could not be started");
      setSession(data); setBuilds(data.builds); setProgress(data.progress); setShopping(data.shopping);
      const params = new URLSearchParams(window.location.search);
      if (params.get("membership") === "success") notify("Stripe checkout returned successfully. Access activates after the verified payment webhook is received.", "success");
      if (params.get("membership") === "cancelled") notify("Checkout was cancelled. No membership change was made.", "info");
    }).catch((error) => notify(`${error instanceof Error ? error.message : "Session error"}. Local planning remains available.`, "error"));

    if ("serviceWorker" in navigator && process.env.NODE_ENV === "production") {
      navigator.serviceWorker.register("/sw.js").catch(() => { /* The online app remains fully usable if registration is blocked. */ });
    }
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll(); window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [notify]);

  useEffect(() => {
    if (draftReady) window.localStorage.setItem("switchcraft_draft", JSON.stringify(config));
  }, [config, draftReady]);

  const nav = [
    { href: "#studio", label: "Build studio" }, { href: "#wire-lab", label: "Wire lab" }, { href: "#academy", label: "Field school" }, { href: "#parts", label: "Parts desk" },
  ];

  return (
    <MotionConfig reducedMotion="user">
    <main>
      <header className={`site-header ${scrolled ? "scrolled" : ""}`}>
        <a className="brand" href="#top" aria-label="Switchcraft home"><svg viewBox="0 0 42 42" aria-hidden="true"><path d="M7 28V14l14-8 14 8v14l-14 8Z" /><path d="M13 24l6-11v8h10l-6 11v-8Z" /></svg><span>SWITCH<em>CRAFT</em></span></a>
        <nav className="desktop-nav" aria-label="Main navigation">{nav.map((item) => <a key={item.href} href={item.href}>{item.label}</a>)}</nav>
        <div className="header-actions"><button className={`trial-chip ${status}`} onClick={() => setMembershipOpen(true)}><span />{!session ? "Starting workshop" : status === "active" ? "Member access" : status === "trial" ? `${session.member.daysLeft} trial days left` : "Trial ended"}</button><a href="#membership" className="header-member">Membership<ArrowUpRight size={14} /></a><button className="mobile-menu-button" onClick={() => setMenuOpen((open) => !open)} aria-label="Toggle navigation" aria-expanded={menuOpen}>{menuOpen ? <X /> : <Menu />}</button></div>
        <AnimatePresence>{menuOpen && <motion.nav className="mobile-nav" initial={{ opacity: 0, y: -15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} aria-label="Mobile navigation">{[...nav, { href: "#membership", label: "Membership + app" }].map((item, index) => <motion.a key={item.href} href={item.href} onClick={() => setMenuOpen(false)} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.04 }}><span>0{index + 1}</span>{item.label}<ArrowUpRight size={16} /></motion.a>)}</motion.nav>}</AnimatePresence>
      </header>

      <Hero />
      <ScrollScene />
      <BuildStudio config={config} onChange={setConfig} status={status} builds={builds} onBuildsChange={setBuilds} onMembership={() => setMembershipOpen(true)} notify={notify} />
      <WireLab baseConfig={config} status={status} onMembership={() => setMembershipOpen(true)} notify={notify} />
      <Academy status={status} progress={progress} onProgressChange={setProgress} onMembership={() => setMembershipOpen(true)} notify={notify} />
      <PartsDesk config={config} shopping={shopping} onShoppingChange={setShopping} notify={notify} />
      <MembershipSection member={session?.member ?? null} notify={notify} />

      <section className="safety-manifesto section-pad"><div className="page-shell"><ShieldAlert size={35} /><span className="eyebrow">THE RULE THAT OUTRANKS EVERY TRICK</span><h2>A switch can drop a car.<br />It cannot hold you up.</h2><p>Use rated mechanical supports before any part of your body enters a crush zone. Hydraulics are not jack stands. Isolate stored electrical energy, respect pressurized fluid and hire out fabrication or diagnostics beyond your training.</p><div><span>MECHANICAL SUPPORT</span><span>RATED COMPONENTS</span><span>NO IMPROVISED EV WORK</span><span>MEASURE BEFORE CUTTING</span></div></div></section>

      <footer className="site-footer"><div className="page-shell"><div className="footer-top"><div><a className="brand footer-brand" href="#top"><CircuitBoard size={30} /><span>SWITCH<em>CRAFT</em></span></a><h3>Keep the culture.<br />Learn the circuit.</h3><p>A fullstack hydraulic planning and learning workshop for first builds, street cars and advanced paired-pump systems.</p></div><div className="footer-links"><div><strong>WORKSHOP</strong>{nav.map((item) => <a key={item.href} href={item.href}>{item.label}</a>)}<a href="#membership">Membership + install</a></div><div><strong>REFERENCE LIBRARY</strong><a href="https://www.coolcars.org/hydraulics-diagrams/" target="_blank" rel="noreferrer">CCE hydraulic diagrams<ArrowUpRight size={12} /></a><a href="https://www.hopposonline.com/hydraulic-suspension-kits/" target="_blank" rel="noreferrer">Hoppo’s kit configurations<ArrowUpRight size={12} /></a><a href="https://www.motortrend.com/how-to-tech/chassis-suspension/1110-lrmp-black-magic-hydraulics-set-up" target="_blank" rel="noreferrer">MotorTrend install walkthrough<ArrowUpRight size={12} /></a><a href="https://www.speedhunters.com/2018/07/the-science-of-hitting-switches/" target="_blank" rel="noreferrer">Speedhunters system explainer<ArrowUpRight size={12} /></a></div></div></div><div className="footer-bottom"><span>© {new Date().getFullYear()} SWITCHCRAFT FIELD SCHOOL</span><span>EDUCATIONAL SCHEMATICS · VERIFY COMPONENT MANUALS & LOCAL RULES</span><a href="/offline">Offline page</a></div></div></footer>

      <Modal open={membershipOpen} onClose={() => setMembershipOpen(false)} title="Choose your workshop access" eyebrow="FIVE-DAY TRIAL / FULL MEMBERSHIP" wide><MembershipOptions member={session?.member ?? null} notify={notify} compact /></Modal>
      <Toast toast={toast} onClose={closeToast} />
    </main>
    </MotionConfig>
  );
}
