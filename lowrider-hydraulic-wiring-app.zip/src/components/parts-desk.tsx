"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Check, Download, ExternalLink, Filter, Minus, PackageCheck, Plus, Search, ShoppingBag, Store, Trash2, Truck } from "lucide-react";
import type { BuildConfig } from "@/lib/hydraulics";
import { getBuildSummary } from "@/lib/hydraulics";
import { formatPrice, getVendor, PRODUCTS, VENDORS, type Product } from "@/lib/catalog";
import type { ClientShoppingItem } from "@/lib/api-types";
import { downloadText, Modal, SectionHeading } from "./ui";

interface PartsDeskProps {
  config: BuildConfig;
  shopping: ClientShoppingItem[];
  onShoppingChange: (items: ClientShoppingItem[]) => void;
  notify: (message: string, kind?: "success" | "error" | "info") => void;
}

export default function PartsDesk({ config, shopping, onShoppingChange, notify }: PartsDeskProps) {
  const [query, setQuery] = useState("");
  const [vendor, setVendor] = useState("all");
  const [category, setCategory] = useState("all");
  const [matchBuild, setMatchBuild] = useState(true);
  const [cartOpen, setCartOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const summary = getBuildSummary(config);
  const categories = ["all", ...new Set(PRODUCTS.map((product) => product.category))];
  const filtered = useMemo(() => PRODUCTS.filter((product) => {
    if (matchBuild && !product.pumps.includes(config.pumpCount)) return false;
    if (vendor !== "all" && product.vendorId !== vendor) return false;
    if (category !== "all" && product.category !== category) return false;
    const seller = getVendor(product.vendorId).name;
    return `${product.name} ${product.note} ${seller} ${product.category}`.toLowerCase().includes(query.toLowerCase());
  }), [matchBuild, vendor, category, query, config.pumpCount]);
  const detailed = shopping.map((item) => ({ ...item, product: PRODUCTS.find((product) => product.id === item.productId)! })).filter((item) => item.product);
  const knownSubtotal = detailed.reduce((sum, item) => sum + (item.product.price ?? 0) * item.quantity, 0);
  const unknownPrices = detailed.filter((item) => item.product.price === null).length;

  const setQuantity = async (product: Product, quantity: number) => {
    if (quantity <= 0) return removeItem(product.id);
    setBusy(product.id);
    const previous = shopping;
    const exists = shopping.some((item) => item.productId === product.id);
    onShoppingChange(exists ? shopping.map((item) => item.productId === product.id ? { ...item, quantity } : item) : [...shopping, { productId: product.id, quantity }]);
    try {
      const response = await fetch("/api/shopping", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ productId: product.id, quantity }) });
      const data = await response.json() as { item?: ClientShoppingItem; error?: string };
      if (!response.ok || !data.item) throw new Error(data.error || "Could not update list");
      onShoppingChange([...previous.filter((item) => item.productId !== product.id), data.item]);
      if (!exists) notify(`${product.name} added to the order board.`, "success");
    } catch (error) {
      onShoppingChange(previous);
      notify(error instanceof Error ? error.message : "List could not be updated.", "error");
    } finally { setBusy(null); }
  };

  const removeItem = async (productId: string) => {
    setBusy(productId);
    const previous = shopping;
    onShoppingChange(shopping.filter((item) => item.productId !== productId));
    const response = await fetch("/api/shopping", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ productId }) });
    if (!response.ok) { onShoppingChange(previous); notify("Item could not be removed.", "error"); }
    setBusy(null);
  };

  const exportList = () => {
    const rows = [["Vendor", "Product", "Quantity", "Reference unit price", "Reference line total", "Live listing", "Fitment note"], ...detailed.map((item) => [getVendor(item.product.vendorId).name, item.product.name, item.quantity, item.product.price ?? "See vendor", item.product.price === null ? "See vendor" : item.product.price * item.quantity, item.product.url, item.product.fitment])];
    const csv = rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
    downloadText("switchcraft-multi-vendor-order-board.csv", csv, "text/csv");
    notify("Order board exported with live vendor links.", "success");
  };

  return (
    <section id="parts" className="parts-section section-pad">
      <div className="page-shell">
        <SectionHeading number="04" eyebrow="THE PARTS DESK" title="One build list. More than one place to buy." copy="Compare real supplier listings, save a multi-vendor order board and finish each purchase on the supplier’s own secure site. Switchcraft does not claim their stock or take their payment." />
        <div className="parts-trust-bar"><div><PackageCheck size={20} /><p><strong>Reference catalog, not a live inventory feed.</strong> Open the vendor listing for current stock, options, shipping, tax and final price.</p></div><button className="button button-dark" onClick={() => setCartOpen(true)}><ShoppingBag size={17} />Order board<span className="count-pill">{shopping.length}</span></button></div>
        <div className="parts-controls">
          <label className="match-toggle"><input type="checkbox" checked={matchBuild} onChange={(event) => setMatchBuild(event.target.checked)} /><span><strong>Match my {config.pumpCount}-pump build</strong><small>{config.vehicleYear} {config.vehicleMake} {config.vehicleModel} · {summary.dumps} dumps · {config.controlVoltage}V controls</small></span></label>
          <label className="search-field"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search pumps, switches, dumps…" /></label>
          <label className="filter-select"><Store size={15} /><select value={vendor} onChange={(event) => setVendor(event.target.value)}><option value="all">All vendors</option>{VENDORS.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}</option>)}</select></label>
          <label className="filter-select"><Filter size={15} /><select value={category} onChange={(event) => setCategory(event.target.value)}>{categories.map((entry) => <option key={entry} value={entry}>{entry === "all" ? "All categories" : entry}</option>)}</select></label>
        </div>
        <div className="catalog-meta"><span>{filtered.length} of {PRODUCTS.length} individually sourced listings</span>{(query || vendor !== "all" || category !== "all" || !matchBuild) && <button className="text-button" onClick={() => { setQuery(""); setVendor("all"); setCategory("all"); setMatchBuild(true); }}>Reset filters</button>}</div>
        <div className="product-grid">{filtered.map((product, index) => {
          const seller = getVendor(product.vendorId);
          const inList = shopping.find((item) => item.productId === product.id);
          return <motion.article className="product-card" key={product.id} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.15 }} transition={{ delay: (index % 3) * 0.05 }}>
            <div className="product-card-top"><span>{product.category}</span><span>{seller.name}</span></div><h3>{product.name}</h3><p className="product-fitment">{product.fitment}</p><p>{product.note}</p><div className="product-tags">{product.pumps.map((pump) => <span key={pump}>{pump}P</span>)}<span>{product.tier === "all" ? "Any tier" : product.tier}</span></div><div className="product-price"><strong>{formatPrice(product.price)}</strong><span>{product.price === null ? "Live vendor price required" : `reference / ${product.unit}`}</span></div><div className="product-actions">{inList ? <div className="quantity-control"><button disabled={busy === product.id} onClick={() => setQuantity(product, inList.quantity - 1)} aria-label={`Decrease ${product.name}`}><Minus size={14} /></button><span>{inList.quantity} in list</span><button disabled={busy === product.id} onClick={() => setQuantity(product, inList.quantity + 1)} aria-label={`Increase ${product.name}`}><Plus size={14} /></button></div> : <button className="button button-outline" disabled={busy === product.id} onClick={() => setQuantity(product, 1)}><Plus size={15} />Add to list</button>}<a className="button button-dark" href={product.url} target="_blank" rel="noreferrer">Check stock & order<ArrowUpRight size={15} /></a></div>
          </motion.article>;
        })}</div>
        {filtered.length === 0 && <div className="empty-state"><Search size={30} /><h4>No supplier listings match</h4><p>For 6- and 8-pump systems, source individual components or ask a vendor to quote a custom kit. The catalog does not invent a complete-kit listing.</p><button className="button button-outline" onClick={() => { setMatchBuild(false); setCategory("all"); setVendor("all"); setQuery(""); }}>Show full catalog</button></div>}

        <div className="vendor-grid">{VENDORS.map((seller) => <article key={seller.id}><Store size={20} /><span className="eyebrow">{seller.location}</span><h3>{seller.name}</h3><p>{seller.specialty}</p><a href={seller.url} target="_blank" rel="noreferrer" className="text-link">Visit supplier<ExternalLink size={14} /></a></article>)}</div>
        <div className="parts-footnote"><Truck size={20} /><p><strong>Before ordering:</strong> send the vendor your exact year/make/model, frame family, cylinder measurements, dump count and coil voltage. Product names and reference prices can change; fitment is not guaranteed by a catalog match.</p></div>
      </div>

      <Modal open={cartOpen} onClose={() => setCartOpen(false)} title="Multi-vendor order board" eyebrow={`${shopping.length} SAVED LINES`} wide>
        {detailed.length === 0 ? <div className="empty-state"><ShoppingBag size={34} /><h4>Your order board is empty</h4><p>Add products from any supplier. Quantities persist with your workshop session.</p></div> : <div className="order-board"><div className="order-board-summary"><div><span>Known-price subtotal</span><strong>${knownSubtotal.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</strong></div><p>{unknownPrices ? `${unknownPrices} line${unknownPrices > 1 ? "s" : ""} still need${unknownPrices === 1 ? "s" : ""} a live vendor price. ` : ""}This is not a checkout total and includes no shipping or tax.</p><button className="button button-outline" onClick={exportList}><Download size={15} />Export CSV</button></div>{VENDORS.map((seller) => {
          const items = detailed.filter((item) => item.product.vendorId === seller.id);
          if (!items.length) return null;
          return <section className="vendor-order-group" key={seller.id}><header><div><Store size={18} /><h4>{seller.name}</h4></div><a href={seller.url} target="_blank" rel="noreferrer">Open supplier<ArrowUpRight size={14} /></a></header>{items.map((item) => <div className="order-line" key={item.productId}><div><strong>{item.product.name}</strong><span>{formatPrice(item.product.price)} reference / {item.product.unit}</span></div><div className="quantity-control"><button onClick={() => setQuantity(item.product, item.quantity - 1)}><Minus size={13} /></button><span>{item.quantity}</span><button onClick={() => setQuantity(item.product, item.quantity + 1)}><Plus size={13} /></button></div><strong>{item.product.price === null ? "Live price" : `$${(item.product.price * item.quantity).toLocaleString()}`}</strong><a className="button button-dark" href={item.product.url} target="_blank" rel="noreferrer">Order at vendor<ExternalLink size={13} /></a><button className="icon-button danger" onClick={() => removeItem(item.productId)} aria-label={`Remove ${item.product.name}`}><Trash2 size={15} /></button></div>)}</section>;
        })}<div className="order-board-disclaimer"><Check size={17} /><p>Each supplier handles its own stock, fitment questions, payment, shipping and returns. Your exported CSV preserves all product links so you can complete separate orders without re-searching.</p></div></div>}
      </Modal>
    </section>
  );
}
