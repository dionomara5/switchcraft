"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, LockKeyhole, X } from "lucide-react";

export function SectionHeading({ number, eyebrow, title, copy, light = false }: { number: string; eyebrow: string; title: string; copy: string; light?: boolean }) {
  return (
    <motion.div className={`section-heading ${light ? "is-light" : ""}`} initial={{ opacity: 0, y: 45 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.35 }} transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}>
      <div className="section-heading-meta"><span>{number}</span><span>{eyebrow}</span></div>
      <h2>{title}</h2>
      <p>{copy}</p>
    </motion.div>
  );
}

export function Modal({ open, onClose, title, eyebrow, children, wide = false }: { open: boolean; onClose: () => void; title: string; eyebrow?: string; children: ReactNode; wide?: boolean }) {
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement as HTMLElement | null;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    document.body.classList.add("modal-open");
    window.setTimeout(() => closeRef.current?.focus(), 40);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.classList.remove("modal-open");
      previous?.focus();
    };
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && <motion.div className="modal-backdrop" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
        <motion.section className={`modal-panel ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title} initial={{ opacity: 0, y: 40, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 25, scale: 0.98 }} transition={{ type: "spring", stiffness: 320, damping: 30 }}>
          <header className="modal-header"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h3>{title}</h3></div><button ref={closeRef} className="icon-button" onClick={onClose} aria-label="Close dialog"><X size={20} /></button></header>
          <div className="modal-body">{children}</div>
        </motion.section>
      </motion.div>}
    </AnimatePresence>
  );
}

export function Toast({ toast, onClose }: { toast: { message: string; kind?: "success" | "error" | "info" } | null; onClose: () => void }) {
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(onClose, 4800);
    return () => window.clearTimeout(timer);
  }, [toast, onClose]);
  return <AnimatePresence>{toast && <motion.div className={`toast toast-${toast.kind ?? "info"}`} role="status" initial={{ opacity: 0, y: 30, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 20 }}><span className="toast-icon">{toast.kind === "success" ? <Check size={16} /> : <span />}</span><p>{toast.message}</p><button onClick={onClose} aria-label="Dismiss notification"><X size={16} /></button></motion.div>}</AnimatePresence>;
}

export function LockedPanel({ title, copy, onUnlock }: { title: string; copy: string; onUnlock: () => void }) {
  return (
    <motion.div className="locked-panel" initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }}>
      <span className="lock-badge"><LockKeyhole size={25} /></span>
      <span className="eyebrow">MEMBERSHIP WORKSHOP</span>
      <h3>{title}</h3>
      <p>{copy}</p>
      <button className="button button-acid" onClick={onUnlock}>See membership options</button>
      <small>No payment is taken by this lock screen.</small>
    </motion.div>
  );
}

export async function copyText(text: string) {
  if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
  const area = document.createElement("textarea");
  area.value = text;
  area.style.position = "fixed";
  area.style.opacity = "0";
  document.body.appendChild(area);
  area.select();
  document.execCommand("copy");
  area.remove();
}

export function downloadText(filename: string, content: string, type = "text/plain") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
