"use client";

import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, Check, CheckCircle2, ClipboardCheck, Download, GraduationCap, LockKeyhole, MousePointer2, RotateCcw, ShieldOff, Zap } from "lucide-react";
import type { BuildConfig, PumpCount, SwitchBoxSize } from "@/lib/hydraulics";
import { getBoxCommands, getSwitchSpec, getWireMap, normalizeConfig } from "@/lib/hydraulics";
import { hasAccess } from "@/lib/access";
import { SwitchBoxDiagram, WireColorLegend } from "./diagrams";
import { downloadText, LockedPanel, SectionHeading } from "./ui";

const LAB_STEPS = [
  { title: "Clear the bench & isolate the car", short: "Prepare", body: "Disconnect the hydraulic service disconnect and verify the system is de-energized. Work on the box away from the car. Gather a continuity meter, labeled cord, ferrules or crimp terminals, strain relief, small fuse holder and the exact momentary switches in your plan.", rule: "No battery power is connected during box construction or continuity testing.", check: "Power isolated, switch specifications confirmed, meter and cord ready." },
  { title: "Mount every switch in one orientation", short: "Orient", body: "Place each locating notch toward the top of the drawing. You are looking at the wiring side, not the decorated handle side. Mark the rear contacts TOP, COMMON and BOTTOM before attaching wires. Do not assume two brands share a terminal arrangement.", rule: "One orientation for every switch prevents mirrored up/down wiring.", check: "Notches up, wiring side visible, every switch labeled by command." },
  { title: "Build the red common ladder", short: "Commons", body: "Connect the fused control feed to each switch's center/common contacts. Use a deliberate wire-in/wire-out ladder or labeled distribution point with properly rated terminations. Avoid twisting a bundle together under tape. Every pole in a multi-pole switch needs the intended common feed.", rule: "Red in this lab means fused control feed—not direct motor current.", check: "All required commons connected; no stray strands or accidental contact with other rows." },
  { title: "Land pump triggers on raise contacts", short: "Raise", body: "Following the wiring-side/notch-up convention in this drawing, connect each pump-trigger channel to a bottom contact. A two-pump FBSS box has front and rear pump channels; a four-pump box has FL, FR, RL and RR. Paired 6/8-pump outputs fan out later at a terminal strip, not through high-current switch contacts.", rule: "Switch wires trigger solenoids. Motor battery current never passes through this box.", check: "Every intended raise channel is on its planned contact; unused contacts are identified." },
  { title: "Land dump triggers on lower contacts", short: "Dump", body: "Connect dump channels to the top contacts in this same drawing convention. Two front dumps need two poles even when one front pump uses only one raise pole. This is why a six-prong switch can be necessary with an apparently simple two-pump system.", rule: "Count both directions before choosing three-, six- or 12-prong switches.", check: "Each dump channel matches its corner label and no dump is accidentally on a raise contact." },
  { title: "Land the cord on a terminal strip", short: "Terminal strip", body: "Number the cord conductors and land each one on a labeled terminal. From there, run the box jumpers. Add strain relief so a pulled cord loads the clamp—not the solder joints or crimps. Leave a small service loop and photograph the open box.", rule: "Colors help you navigate; terminal numbers make the circuit serviceable.", check: "Cord secured, both ends labeled, terminal map and open-box photo saved." },
  { title: "Prove the whole matrix with a meter", short: "Continuity", body: "With power still disconnected, test every switch in center-off, raise and lower positions. Center should isolate the outputs. Raise should connect common only to intended pump channels. Lower should connect common only to intended dump channels. Record each passed test below.", rule: "A good-looking box can still be wired wrong. The continuity matrix is the proof.", check: "Every command passes all three states before power is introduced." },
  { title: "Perform the first powered test safely", short: "First power", body: "Support the vehicle mechanically and keep everyone clear of crush zones. Connect the correctly rated, fused control supply. Test one output at a time and confirm the actual corner matches its label. Stop immediately for heat, stuck solenoids, unexpected movement or a switch that does not spring back.", rule: "The first test is for verification, not hopping or speed.", check: "All outputs correct, no heat or sticking, then isolate power before close inspection." },
];

const QUIZ = [
  { question: "Why does a two-pump front switch sometimes need six prongs?", options: ["To carry motor current", "One pump raise channel but two front dump channels", "To charge two batteries", "To reverse the pump"], answer: 1 },
  { question: "Where should paired six- or eight-pump trigger channels fan out?", options: ["At a labeled terminal strip", "Inside a tire", "At the cylinder rod", "Behind a taped twist"], answer: 0 },
  { question: "What proves a switch box before power is connected?", options: ["Its color", "A continuity test of off, raise and lower", "Shaking it", "A larger fuse"], answer: 1 },
];

interface WireLabProps {
  baseConfig: BuildConfig;
  status: "active" | "trial" | "expired";
  onMembership: () => void;
  notify: (message: string, kind?: "success" | "error" | "info") => void;
}

export default function WireLab({ baseConfig, status, onMembership, notify }: WireLabProps) {
  const [pumpCount, setPumpCount] = useState<PumpCount>(2);
  const [boxSize, setBoxSize] = useState<SwitchBoxSize>(4);
  const [step, setStep] = useState(0);
  const [terminalMessage, setTerminalMessage] = useState("Select any terminal in the drawing to inspect its assigned function.");
  const [tested, setTested] = useState<string[]>([]);
  const [quizAnswers, setQuizAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const config = useMemo(() => normalizeConfig({ ...baseConfig, pumpCount, layout: pumpCount === 2 ? "fbss" : "independent", switchBox: boxSize, boostedAxle: "front" }), [baseConfig, pumpCount, boxSize]);
  const commands = useMemo(() => getBoxCommands(config, boxSize), [config, boxSize]);
  const locked = (boxSize >= 6 || pumpCount === 4) && !hasAccess(status, boxSize >= 6 ? "pro" : "trial");
  const requiredTests = commands.length * 3;
  const score = QUIZ.reduce((total, question, index) => total + (quizAnswers[index] === question.answer ? 1 : 0), 0);
  const switchCounts = commands.reduce((counts, command) => {
    const prongs = getSwitchSpec(command).prongs;
    counts[prongs] = (counts[prongs] ?? 0) + 1;
    return counts;
  }, {} as Record<number, number>);

  useEffect(() => {
    try {
      const key = `switchcraft_lab_${pumpCount}_${boxSize}`;
      const saved = window.localStorage.getItem(key);
      if (saved) {
        const parsed = JSON.parse(saved) as { step?: number; tested?: string[] };
        setStep(Math.min(7, parsed.step ?? 0));
        setTested(parsed.tested ?? []);
      } else { setStep(0); setTested([]); }
    } catch { setStep(0); setTested([]); }
    setQuizAnswers({});
    setQuizSubmitted(false);
  }, [pumpCount, boxSize]);

  useEffect(() => {
    window.localStorage.setItem(`switchcraft_lab_${pumpCount}_${boxSize}`, JSON.stringify({ step, tested }));
  }, [step, tested, pumpCount, boxSize]);

  const exportDiagram = () => {
    const svg = document.getElementById("wire-lab-diagram");
    if (!svg) return;
    const clone = svg.cloneNode(true) as SVGElement;
    clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
    style.textContent = `.diagram-eyebrow,.diagram-section,.diagram-copy,.diagram-micro{font-family:Arial,sans-serif;fill:#dce4dc}.diagram-eyebrow{font-size:11px;letter-spacing:2px}.diagram-section{font-size:12px;font-weight:bold}.diagram-copy,.diagram-micro{font-size:10px}`;
    clone.prepend(style);
    downloadText(`switchcraft-${pumpCount}p-${boxSize}-switch-wiring.svg`, new XMLSerializer().serializeToString(clone), "image/svg+xml");
    notify("Wire Lab drawing exported.", "success");
  };

  return (
    <section id="wire-lab" className="wire-lab-section section-pad">
      <div className="page-shell">
        <SectionHeading number="02" eyebrow="THE WIRE LAB" title="An empty box becomes a system you understand." copy="Work from the wiring side, one terminal at a time. The drawing changes with your pump layout and box size; the meter checklist makes you prove the logic before first power." light />
        <div className="lab-config-bar">
          <div><span className="eyebrow">TRAINING HARNESS</span><strong>Choose what you want to wire</strong></div>
          <div className="lab-choice"><span>Pump map</span><div className="segmented">{([2, 4] as PumpCount[]).map((count) => <button key={count} className={pumpCount === count ? "selected" : ""} onClick={() => setPumpCount(count)}>{count} pumps{count === 4 && status === "expired" ? " · locked" : ""}</button>)}</div></div>
          <div className="lab-choice"><span>Box size</span><div className="segmented">{([2, 4, 6, 10] as SwitchBoxSize[]).map((size) => <button key={size} className={boxSize === size ? "selected" : ""} onClick={() => setBoxSize(size)}>{size} switches{size >= 6 && status !== "active" ? <LockKeyhole size={11} /> : null}</button>)}</div></div>
        </div>

        {locked ? <LockedPanel title={boxSize >= 6 ? "Advanced switch-box construction" : "Your trial wiring workshop has ended"} copy={boxSize >= 6 ? "Two- and four-switch fundamentals are the trial curriculum. Six- and ten-switch boxes include advanced multi-pole combination wiring and are part of active membership." : "Membership reopens the guided four-pump harness, continuity matrix and advanced switch-box lessons."} onUnlock={onMembership} /> : <>
          <div className="lab-layout">
            <aside className="lab-step-list">
              <div className="lab-progress-head"><span className="eyebrow">FROM SCRATCH</span><strong>{Math.round((step + 1) / LAB_STEPS.length * 100)}% through the bench process</strong><div className="progress-track"><span style={{ width: `${(step + 1) / LAB_STEPS.length * 100}%` }} /></div></div>
              {LAB_STEPS.map((item, index) => <button key={item.title} className={step === index ? "active" : step > index ? "passed" : ""} onClick={() => setStep(index)}><span>{step > index ? <Check size={14} /> : String(index + 1).padStart(2, "0")}</span><div><strong>{item.short}</strong><small>{item.title}</small></div></button>)}
            </aside>
            <div className="lab-canvas">
              <AnimatePresence mode="wait"><motion.div className="lab-instruction" key={step} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -15 }}>
                <div className="lab-step-number">{String(step + 1).padStart(2, "0")}</div><div><span className="eyebrow">BENCH STEP {step + 1} OF 8</span><h3>{LAB_STEPS[step].title}</h3><p>{LAB_STEPS[step].body}</p><div className="lab-rule">{step === 0 ? <ShieldOff size={18} /> : step === 6 ? <ClipboardCheck size={18} /> : <Zap size={18} />}<strong>{LAB_STEPS[step].rule}</strong></div><small className="lab-check"><CheckCircle2 size={15} />Done when: {LAB_STEPS[step].check}</small></div>
              </motion.div></AnimatePresence>
              <div className="lab-diagram-toolbar"><span><MousePointer2 size={15} />Click a terminal to inspect it</span><button onClick={exportDiagram}><Download size={15} />Export SVG</button></div>
              <SwitchBoxDiagram config={config} size={boxSize} step={Math.min(step, 5)} onTerminal={setTerminalMessage} diagramId="wire-lab-diagram" />
              <motion.div className="terminal-readout" key={terminalMessage} initial={{ opacity: 0 }} animate={{ opacity: 1 }}><span>TERMINAL INSPECTOR</span><p>{terminalMessage}</p></motion.div>
              <div className="lab-navigation"><button className="button button-outline-light" disabled={step === 0} onClick={() => setStep((current) => Math.max(0, current - 1))}><ArrowLeft size={16} />Previous</button><span>{step + 1} / 8</span>{step < 7 ? <button className="button button-acid" onClick={() => setStep((current) => Math.min(7, current + 1))}>Next bench step<ArrowRight size={16} /></button> : <button className="button button-acid" onClick={() => setStep(0)}><RotateCcw size={16} />Review from start</button>}</div>
            </div>
          </div>

          <div className="lab-bench-grid">
            <section className="lab-parts-card"><span className="eyebrow">BENCH PARTS FOR THIS BOX</span><h3>No mystery switch count</h3><p>Pole counts come from the commands in your selected pump map. Empty contacts are expected when raise and lower channel counts differ.</p><ul>{Object.entries(switchCounts).map(([prongs, count]) => <li key={prongs}><strong>{count} ×</strong><span>{prongs}-prong momentary switch{count > 1 ? "es" : ""}</span></li>)}<li><strong>1 ×</strong><span>{getWireMap(config).length}-conductor used map; multi-wire cord with spares recommended</span></li><li><strong>1 ×</strong><span>Numbered terminal strip, strain relief, control fuse and labels</span></li></ul><WireColorLegend config={config} /></section>
            <section className="continuity-card"><span className="eyebrow">UNPOWERED CONTINUITY MATRIX</span><h3>{tested.length} / {requiredTests} checks signed off</h3><p>Only mark a cell after your meter confirms it. These checks are a record of your test—they do not perform an electrical test for you.</p><div className="continuity-grid"><div className="continuity-header"><span>Command</span><span>Center off</span><span>Raise</span><span>Lower</span></div>{commands.map((command) => <div className="continuity-row" key={command.id}><strong>{command.shortLabel}</strong>{["off", "up", "down"].map((direction) => { const key = `${command.id}-${direction}`; const pass = tested.includes(key); return <button key={key} className={pass ? "passed" : ""} onClick={() => setTested((current) => pass ? current.filter((item) => item !== key) : [...current, key])} aria-label={`${pass ? "Clear" : "Mark"} ${command.label} ${direction} continuity test`}>{pass ? <Check size={14} /> : <span />}</button>; })}</div>)}</div><div className="progress-track"><span style={{ width: `${tested.length / requiredTests * 100}%` }} /></div></section>
          </div>

          <section className="lab-quiz"><div><span className="eyebrow">5TH-GRADER CHECK · NO TRICK WORDS</span><h3>Can you explain the box to a friend?</h3><p>Choose an answer for each question, then check your score. Wrong answers stay visible so you can revisit the exact bench step.</p></div><div className="quiz-questions">{QUIZ.map((question, questionIndex) => <fieldset key={question.question}><legend>{questionIndex + 1}. {question.question}</legend>{question.options.map((option, optionIndex) => <label key={option} className={quizSubmitted ? optionIndex === question.answer ? "correct" : quizAnswers[questionIndex] === optionIndex ? "incorrect" : "" : ""}><input type="radio" name={`lab-q-${questionIndex}`} checked={quizAnswers[questionIndex] === optionIndex} onChange={() => { setQuizAnswers((current) => ({ ...current, [questionIndex]: optionIndex })); setQuizSubmitted(false); }} />{option}{quizSubmitted && optionIndex === question.answer && <Check size={14} />}</label>)}</fieldset>)}<button className="button button-acid" disabled={Object.keys(quizAnswers).length < QUIZ.length} onClick={() => { setQuizSubmitted(true); if (score === QUIZ.length) notify("Perfect Wire Lab score.", "success"); }}><GraduationCap size={17} />Check my answers</button>{quizSubmitted && <motion.p className="quiz-score" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>You scored {score} / {QUIZ.length}. {score === QUIZ.length ? "You can trace the control logic." : "Review the green answers and try again."}</motion.p>}</div></section>
        </>}
      </div>
    </section>
  );
}
