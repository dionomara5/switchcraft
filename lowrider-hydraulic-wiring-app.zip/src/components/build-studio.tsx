"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDown, ArrowUp, Bookmark, Check, ChevronDown, CircuitBoard, Download, ExternalLink, FileJson, FolderOpen, Gauge, ListChecks, LockKeyhole, Printer, Save, Share2, ShieldAlert, Trash2, Wrench } from "lucide-react";
import type { BuildConfig, PumpCount } from "@/lib/hydraulics";
import { DEFAULT_CONFIG, getBatteryPlan, getBom, getBoxCommands, getBuildSummary, getInstallSteps, getLayoutOptions, normalizeConfig } from "@/lib/hydraulics";
import { getEraGuide, getVehicleProfile, VEHICLE_PROFILES } from "@/lib/content";
import { hasAccess } from "@/lib/access";
import type { ClientBuild } from "@/lib/api-types";
import { ActiveTest, PlumbingDiagram, PowerDiagram, SwitchBoxDiagram, SystemDiagram, WireColorLegend } from "./diagrams";
import { copyText, downloadText, LockedPanel, Modal, SectionHeading } from "./ui";

type AccessStatus = "active" | "trial" | "expired";
type StudioTab = "overview" | "power" | "plumbing" | "switch" | "steps" | "bom";

interface BuildStudioProps {
  config: BuildConfig;
  onChange: (config: BuildConfig) => void;
  status: AccessStatus;
  builds: ClientBuild[];
  onBuildsChange: (builds: ClientBuild[]) => void;
  onMembership: () => void;
  notify: (message: string, kind?: "success" | "error" | "info") => void;
}

const PUMP_CARDS: { count: PumpCount; name: string; detail: string }[] = [
  { count: 2, name: "Two pump", detail: "FB, FBSS or FBCC · axle lift" },
  { count: 4, name: "Four pump", detail: "One pump per corner · full control" },
  { count: 6, name: "Six pump", detail: "Paired front or rear corners" },
  { count: 8, name: "Eight pump", detail: "Two checked pumps per corner" },
];

export default function BuildStudio({ config, onChange, status, builds, onBuildsChange, onMembership, notify }: BuildStudioProps) {
  const [tab, setTab] = useState<StudioTab>("overview");
  const [activeTest, setActiveTest] = useState<ActiveTest | null>(null);
  const [saveOpen, setSaveOpen] = useState(false);
  const [buildsOpen, setBuildsOpen] = useState(false);
  const [saveName, setSaveName] = useState("");
  const [saving, setSaving] = useState(false);
  const [checkedSteps, setCheckedSteps] = useState<number[]>([]);
  const testTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const summary = useMemo(() => getBuildSummary(config), [config]);
  const bom = useMemo(() => getBom(config), [config]);
  const steps = useMemo(() => getInstallSteps(config), [config]);
  const commands = useMemo(() => getBoxCommands(config), [config]);
  const era = getEraGuide(config.vehicleYear);
  const vehicleProfile = getVehicleProfile(config.vehicleMake, config.vehicleModel, config.vehicleYear);
  const battery = getBatteryPlan(config);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem("switchcraft_checked_steps");
      if (saved) setCheckedSteps(JSON.parse(saved) as number[]);
    } catch { /* Local storage can be disabled without blocking the studio. */ }
  }, []);

  useEffect(() => {
    window.localStorage.setItem("switchcraft_checked_steps", JSON.stringify(checkedSteps));
  }, [checkedSteps]);

  useEffect(() => () => { if (testTimer.current) clearTimeout(testTimer.current); }, []);

  const update = <K extends keyof BuildConfig>(key: K, value: BuildConfig[K]) => {
    const next = normalizeConfig({ ...config, [key]: value });
    if (key === "pumpCount") {
      next.layout = value === 2 ? "fbss" : "independent";
      next.switchBox = value === 2 ? 4 : 10;
    }
    if (key === "motorVoltage") {
      next.batteryCount = Number(value) / 12 * battery.strings;
      if (Number(value) === 12) next.controlVoltage = 12;
      else if (config.motorVoltage === 12) next.controlVoltage = 24;
    }
    setActiveTest(null);
    onChange(next);
  };

  const requirementMet = (targetTab: StudioTab) => {
    if (["overview", "bom"].includes(targetTab)) return true;
    if (config.pumpCount > 4 || (targetTab === "switch" && config.switchBox === 10)) return hasAccess(status, "pro");
    return hasAccess(status, "trial");
  };

  const runTest = (commandIndex: number, direction: "up" | "down") => {
    const command = commands[commandIndex];
    if (!command) return;
    setActiveTest({ command, direction });
    if (testTimer.current) clearTimeout(testTimer.current);
    testTimer.current = setTimeout(() => setActiveTest(null), 2400);
  };

  const openSave = () => {
    if (config.pumpCount > 4 && !hasAccess(status, "pro")) {
      onMembership();
      return;
    }
    setSaveName(`${config.vehicleYear} ${config.vehicleMake} ${config.vehicleModel} · ${config.pumpCount}P`);
    setSaveOpen(true);
  };

  const saveBuild = async () => {
    if (!saveName.trim()) return;
    setSaving(true);
    try {
      const response = await fetch("/api/builds", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: saveName, config }) });
      const data = await response.json() as { build?: ClientBuild; error?: string };
      if (!response.ok || !data.build) throw new Error(data.error || "Save failed");
      onBuildsChange([data.build, ...builds]);
      setSaveOpen(false);
      notify("Build saved to your workshop.", "success");
    } catch (error) {
      notify(error instanceof Error ? error.message : "Build could not be saved.", "error");
    } finally { setSaving(false); }
  };

  const deleteBuild = async (id: string) => {
    const previous = builds;
    onBuildsChange(builds.filter((build) => build.id !== id));
    const response = await fetch("/api/builds", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id }) });
    if (!response.ok) {
      onBuildsChange(previous);
      notify("The saved build could not be removed.", "error");
    } else notify("Saved build removed.", "info");
  };

  const shareBuild = async () => {
    const url = `${window.location.origin}${window.location.pathname}?build=${encodeURIComponent(JSON.stringify(config))}#studio`;
    try {
      if (navigator.share) {
        await navigator.share({ title: `${config.pumpCount}-pump Switchcraft plan`, text: "Open this live hydraulic configuration in Switchcraft.", url });
      } else {
        await copyText(url);
        notify("Share link copied. It contains the complete build configuration.", "success");
      }
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") return;
      await copyText(url);
      notify("Share link copied.", "success");
    }
  };

  const exportSvg = () => {
    const id = tab === "overview" ? "system-diagram" : tab === "power" ? "power-diagram" : tab === "plumbing" ? "plumbing-diagram" : "switchbox-diagram";
    const svg = document.getElementById(id);
    if (!svg) return;
    const clone = svg.cloneNode(true) as SVGElement;
    clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    const style = document.createElementNS("http://www.w3.org/2000/svg", "style");
    style.textContent = `.diagram-eyebrow,.diagram-section,.diagram-copy,.diagram-label,.diagram-corner,.diagram-micro{font-family:Arial,sans-serif;fill:#dce4dc}.diagram-eyebrow{font-size:11px;letter-spacing:2px}.diagram-section{font-size:12px;font-weight:700}.diagram-copy{font-size:11px}.diagram-label,.diagram-corner,.diagram-micro{font-size:10px}.oil-flow{stroke-dasharray:10 8}`;
    clone.prepend(style);
    downloadText(`switchcraft-${config.pumpCount}p-${tab}.svg`, new XMLSerializer().serializeToString(clone), "image/svg+xml");
    notify("Color-coded SVG exported.", "success");
  };

  const exportJson = () => {
    downloadText(`switchcraft-${config.pumpCount}p-build.json`, JSON.stringify({ exportedAt: new Date().toISOString(), config, summary, steps }, null, 2), "application/json");
    notify("Build file exported with configuration and steps.", "success");
  };

  const exportBom = () => {
    const rows = [["Category", "Part", "Quantity", "Unit", "Planning low", "Planning high", "Note"], ...bom.map((item) => [item.category, item.name, item.quantity, item.unit, item.low, item.high, item.note])];
    const csv = rows.map((row) => row.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(",")).join("\n");
    downloadText(`switchcraft-${config.pumpCount}p-bom.csv`, csv, "text/csv");
    notify("Shopping quantities exported as CSV.", "success");
  };

  const tabItems: { id: StudioTab; label: string }[] = [
    { id: "overview", label: "System" }, { id: "power", label: "Power" }, { id: "plumbing", label: "Plumbing" }, { id: "switch", label: "Switch box" }, { id: "steps", label: "Install steps" }, { id: "bom", label: "Parts list" },
  ];

  return (
    <section id="studio" className="studio-section section-pad">
      <div className="page-shell">
        <SectionHeading number="01" eyebrow="THE BUILD STUDIO" title="Your car. Your setup. Every wire in its place." copy="Configure the system, test its logic, follow the build order and take the exact same plan to the parts counter. Nothing here is a generic pump-count sticker." />
        <div className="studio-summary-bar">
          <div><span>VEHICLE</span><strong>{config.vehicleYear} {config.vehicleMake} {config.vehicleModel}</strong></div>
          <div><span>CIRCUIT</span><strong>{config.pumpCount} pumps / {summary.dumps} dumps</strong></div>
          <div><span>POWER</span><strong>{battery.series}S × {battery.strings}P / {config.motorVoltage}V</strong></div>
          <div><span>PLANNING RANGE</span><strong>${summary.low.toLocaleString()}–${summary.high.toLocaleString()}</strong></div>
        </div>

        <div className="studio-workbench">
          <aside className="config-panel">
            <div className="config-panel-heading"><span className="eyebrow">BUILD INPUTS</span><button className="text-button" onClick={() => onChange(DEFAULT_CONFIG)}>Reset</button></div>
            <label className="field-label">Start from a known vehicle <span>optional</span>
              <select value="" onChange={(event) => {
                const profile = VEHICLE_PROFILES[Number(event.target.value)];
                if (!profile) return;
                const years = profile.years.match(/\d{4}/g)?.map(Number) ?? [1964];
                onChange(normalizeConfig({ ...config, vehicleMake: profile.make, vehicleModel: profile.model === "any" ? "Model" : profile.model, vehicleYear: years[0] }));
              }}>
                <option value="">Choose an example profile</option>
                {VEHICLE_PROFILES.map((profile, index) => <option key={`${profile.make}-${profile.model}-${profile.years}`} value={index}>{profile.make} {profile.model} · {profile.years}</option>)}
              </select>
            </label>
            <div className="vehicle-fields">
              <label className="field-label">Year<input type="number" min="1920" max={new Date().getFullYear()} value={config.vehicleYear} onChange={(event) => update("vehicleYear", Number(event.target.value))} /></label>
              <label className="field-label">Make<input value={config.vehicleMake} onChange={(event) => update("vehicleMake", event.target.value)} /></label>
              <label className="field-label model-field">Model<input value={config.vehicleModel} onChange={(event) => update("vehicleModel", event.target.value)} placeholder="Any model" /></label>
            </div>
            <p className="field-help">Any year from 1920 to {new Date().getFullYear()} works. The era guide adapts even when your exact model is not listed.</p>

            <fieldset className="config-group"><legend>Pump system</legend><div className="pump-picker">{PUMP_CARDS.map((card) => <button key={card.count} className={config.pumpCount === card.count ? "selected" : ""} onClick={() => update("pumpCount", card.count)}><strong>{card.count}P</strong><span>{card.detail}</span>{card.count > 4 && status !== "active" && <LockKeyhole size={12} />}</button>)}</div></fieldset>
            <label className="field-label">Control layout<select value={config.layout} onChange={(event) => update("layout", event.target.value as BuildConfig["layout"])}>{getLayoutOptions(config.pumpCount).map((layout) => <option key={layout.id} value={layout.id}>{layout.name} — {layout.detail}</option>)}</select></label>
            {config.pumpCount === 6 && <label className="field-label">Where should paired pumps work?<select value={config.boostedAxle} onChange={(event) => update("boostedAxle", event.target.value as BuildConfig["boostedAxle"])}><option value="front">Two pumps per front corner</option><option value="rear">Two pumps per rear corner</option></select></label>}
            <fieldset className="config-group"><legend>Build priority</legend><div className="segmented">{(["backyard", "street", "show"] as const).map((tier) => <button key={tier} className={config.tier === tier ? "selected" : ""} onClick={() => update("tier", tier)}>{tier === "backyard" ? "Backyard" : tier === "street" ? "Street" : "Show"}</button>)}</div><p className="field-help">{config.tier === "backyard" ? "Two solenoids per pump, serviceable basics, no chrome premium." : config.tier === "street" ? "Three solenoids per pump, accumulators recommended, cruising focus." : "Three solenoids per pump with a finish/plumbing allowance. Structure still comes first."}</p></fieldset>

            <div className="two-fields">
              <label className="field-label">Motor bus<select value={config.motorVoltage} onChange={(event) => update("motorVoltage", Number(event.target.value) as BuildConfig["motorVoltage"])}>{[12, 24, 36, 48, 60, 72].map((voltage) => <option key={voltage} value={voltage}>{voltage}V · {voltage / 12} in series</option>)}</select></label>
              <label className="field-label">Parallel strings<select value={battery.strings} onChange={(event) => update("batteryCount", battery.series * Number(event.target.value))}>{[1, 2, 3, 4].map((count) => <option key={count} value={count}>{count} string{count > 1 ? "s" : ""} · {count * battery.series} batt.</option>)}</select></label>
              <label className="field-label">Control supply<select value={config.controlVoltage} onChange={(event) => update("controlVoltage", Number(event.target.value) as BuildConfig["controlVoltage"])} disabled={config.motorVoltage === 12}><option value="12">12V coils / triggers</option>{config.motorVoltage >= 24 && <option value="24">24V coils / triggers</option>}</select></label>
              <label className="field-label">Switch box<select value={config.switchBox} onChange={(event) => update("switchBox", Number(event.target.value) as BuildConfig["switchBox"])}>{[2, 4, 6, 10].map((size) => <option key={size} value={size}>{size} switches{size === 10 ? " · Pro detail" : ""}</option>)}</select></label>
              <label className="field-label">Front cylinders<select value={config.frontCylinder} onChange={(event) => update("frontCylinder", Number(event.target.value) as BuildConfig["frontCylinder"])}>{[6, 8, 10, 12].map((size) => <option key={size} value={size}>{size}-inch nominal</option>)}</select></label>
              <label className="field-label">Rear cylinders<select value={config.rearCylinder} onChange={(event) => update("rearCylinder", Number(event.target.value) as BuildConfig["rearCylinder"])}>{[6, 8, 10, 12, 14].map((size) => <option key={size} value={size}>{size}-inch nominal</option>)}</select></label>
            </div>
            <label className="toggle-row"><input type="checkbox" checked={config.accumulators} onChange={(event) => update("accumulators", event.target.checked)} /><span><strong>Four accumulators</strong><small>Street compliance option; follow precharge specs.</small></span></label>
            <div className="config-actions"><button className="button button-dark" onClick={openSave}><Save size={16} />Save</button><button className="button button-outline" onClick={() => setBuildsOpen(true)}><FolderOpen size={16} />Saved <span className="count-pill">{builds.length}</span></button></div>
          </aside>

          <div className="diagram-workspace">
            <div className="workspace-toolbar">
              <div className="diagram-tabs" role="tablist" aria-label="Build drawing views">{tabItems.map((item) => <button role="tab" aria-selected={tab === item.id} key={item.id} className={tab === item.id ? "active" : ""} onClick={() => setTab(item.id)}>{item.label}{!requirementMet(item.id) && <LockKeyhole size={11} />}</button>)}</div>
              <div className="export-actions">
                <button onClick={shareBuild} title="Share this configuration"><Share2 size={16} /><span>Share</span></button>
                {["overview", "power", "plumbing", "switch"].includes(tab) && requirementMet(tab) && <button onClick={exportSvg} title="Download the visible diagram"><Download size={16} /><span>SVG</span></button>}
                <button onClick={exportJson} title="Export configuration and install steps"><FileJson size={16} /><span>JSON</span></button>
                <button onClick={() => window.print()} title="Print build plan"><Printer size={16} /><span>Print</span></button>
              </div>
            </div>

            <div className="workspace-content">
              <AnimatePresence mode="wait">
                <motion.div key={`${tab}-${requirementMet(tab)}`} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.22 }}>
                  {!requirementMet(tab) ? <LockedPanel title={config.pumpCount > 4 ? `${config.pumpCount}-pump detail is an advanced workshop` : "Your five-day workshop access has ended"} copy={config.pumpCount > 4 ? "The overview remains visible so you can compare systems. Full paired-pump power, plumbing, switch wiring and build steps are included with active membership." : "The system overview and parts finder remain available. Membership reopens detailed diagrams, switch-box construction and guided installation."} onUnlock={onMembership} /> : <>
                    {tab === "overview" && <>
                      <SystemDiagram config={config} activeTest={activeTest} />
                      <div className="command-console">
                        <div className="command-console-heading"><div><span className="eyebrow">LOGIC SIMULATOR</span><h3>Hit a switch. Watch the circuit.</h3></div><p>Bright lines show the selected command. This is an on-screen test only; it never operates hardware.</p></div>
                        <div className="command-grid">{commands.map((command, index) => <div className={`command-item ${activeTest?.command.id === command.id ? "active" : ""}`} key={command.id}><span>{command.shortLabel}</span><div><button disabled={!command.upChannels.length} onClick={() => runTest(index, "up")} aria-label={`Test ${command.label} raise`}><ArrowUp size={15} /></button><button disabled={!command.downChannels.length} onClick={() => runTest(index, "down")} aria-label={`Test ${command.label} dump`}><ArrowDown size={15} /></button></div><small>{command.upChannels.length} up / {command.downChannels.length} down</small></div>)}</div>
                        {activeTest && <motion.div className="test-readout" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}><Gauge size={18} /><div><strong>{activeTest.command.label} · {activeTest.command.id === "seesaw" ? "combination" : activeTest.direction === "up" ? "raise" : "dump"}</strong><span>{activeTest.command.description}</span></div></motion.div>}
                      </div>
                    </>}
                    {tab === "power" && <><div className="diagram-notice"><ShieldAlert size={18} /><p><strong>{config.motorVoltage}V can be dangerous.</strong> This drawing assumes matched batteries and correctly rated motors, coils, cables, fuses and disconnects. Isolate power before continuity testing; verify component instructions.</p></div><PowerDiagram config={config} /></>}
                    {tab === "plumbing" && <><PlumbingDiagram config={config} activeTest={activeTest} /><div className="inline-callout"><CircuitBoard size={19} /><p>Each colored path is a corner circuit. On 6- and 8-pump plans, two separate checked outlets join before the cylinder. Run tests in the System tab to animate these same paths.</p></div></>}
                    {tab === "switch" && <><SwitchBoxDiagram config={config} step={5} /><div className="wire-map-panel"><div><span className="eyebrow">SWITCHCRAFT REFERENCE CODE</span><h3>{summary.conductors} used conductors</h3><p>Colors are this project's consistent reference—not a promise about a store-bought cord. Label and meter every function.</p><a href="#wire-lab" className="text-link">Open the guided Wire Lab <ExternalLink size={14} /></a></div><WireColorLegend config={config} /></div></>}
                    {tab === "steps" && <div className="install-steps"><div className="steps-progress"><div><span className="eyebrow">YOUR BUILD CHECKLIST</span><strong>{checkedSteps.length} of {steps.length} stages checked</strong></div><div className="progress-track"><span style={{ width: `${checkedSteps.length / steps.length * 100}%` }} /></div><button className="text-button" onClick={() => setCheckedSteps([])}>Clear checks</button></div>{steps.map((step, index) => <article className={`install-step ${checkedSteps.includes(index) ? "complete" : ""}`} key={step.title}><button className="step-check" onClick={() => setCheckedSteps((current) => current.includes(index) ? current.filter((value) => value !== index) : [...current, index])} aria-label={`${checkedSteps.includes(index) ? "Uncheck" : "Check"} step ${index + 1}`}>{checkedSteps.includes(index) ? <Check size={17} /> : <span>{String(index + 1).padStart(2, "0")}</span>}</button><div><h3>{step.title}</h3><p>{step.detail}</p><small><ListChecks size={14} />Done when: {step.check}</small></div></article>)}</div>}
                    {tab === "bom" && <div className="bom-panel"><div className="bom-heading"><div><span className="eyebrow">GENERATED FROM THIS EXACT BUILD</span><h3>{bom.length} shopping lines</h3><p>Planning estimates are not quotes. Fabrication, shipping, taxes, chargers and specialty tools may be extra.</p></div><div><button className="button button-outline" onClick={exportBom}><Download size={15} />CSV</button><a className="button button-acid" href="#parts"><Wrench size={15} />Find parts</a></div></div><div className="bom-table-wrap"><table className="bom-table"><thead><tr><th>Part</th><th>Qty</th><th>Planning range</th><th>Why / specification</th></tr></thead><tbody>{bom.map((item, index) => <tr key={`${item.id}-${index}`}><td><span>{item.category}</span><strong>{item.name}</strong></td><td>{item.quantity} {item.unit}{item.quantity === 1 ? "" : ""}</td><td>${item.low.toLocaleString()}–${item.high.toLocaleString()}</td><td>{item.note}</td></tr>)}</tbody><tfoot><tr><td colSpan={2}>Estimated parts total</td><td>${summary.low.toLocaleString()}–${summary.high.toLocaleString()}</td><td>Before unlisted work, shipping and tax</td></tr></tfoot></table></div></div>}
                  </>}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>

        <motion.div className="vehicle-era-card" initial={{ opacity: 0, y: 25 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
          <div><span className="eyebrow">{era.range[0]}–{era.range[1]} VEHICLE GUIDE</span><h3>{era.title}</h3><p>{era.plan}</p></div>
          <dl><div><dt>Electrical baseline</dt><dd>{era.electrical}</dd></div><div><dt>Structure</dt><dd>{era.structure}</dd></div><div><dt>{vehicleProfile ? "Exact profile note" : "Era caution"}</dt><dd>{vehicleProfile?.note ?? era.warning}</dd></div></dl>
        </motion.div>
      </div>

      <Modal open={saveOpen} onClose={() => setSaveOpen(false)} title="Save this build" eyebrow="YOUR WORKSHOP">
        <p className="modal-copy">Stores the vehicle, pump layout, power plan, cylinders, controls and all generated quantities. Your checklist stays on this device.</p>
        <label className="field-label">Build name<input autoFocus value={saveName} onChange={(event) => setSaveName(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") saveBuild(); }} /></label>
        <div className="modal-actions"><button className="button button-outline" onClick={() => setSaveOpen(false)}>Cancel</button><button className="button button-acid" disabled={saving || !saveName.trim()} onClick={saveBuild}><Bookmark size={16} />{saving ? "Saving…" : "Save build"}</button></div>
      </Modal>

      <Modal open={buildsOpen} onClose={() => setBuildsOpen(false)} title="Saved builds" eyebrow={`${builds.length} OF 30 WORKSHOP SLOTS`} wide>
        {builds.length === 0 ? <div className="empty-state"><FolderOpen size={32} /><h4>No saved builds yet</h4><p>Configure a system, then select Save. Your plans will be tied to this workshop session.</p></div> : <div className="saved-build-list">{builds.map((build) => <article key={build.id}><div><span>{build.config.pumpCount}P · {build.config.motorVoltage}V · {build.config.batteryCount} batteries</span><h4>{build.name}</h4><small>Updated {new Date(build.updatedAt).toLocaleDateString()}</small></div><div><button className="button button-dark" onClick={() => { onChange(normalizeConfig(build.config)); setBuildsOpen(false); setActiveTest(null); notify(`Loaded ${build.name}.`, "success"); }}>Load build</button><button className="icon-button danger" onClick={() => deleteBuild(build.id)} aria-label={`Delete ${build.name}`}><Trash2 size={17} /></button></div></article>)}</div>}
      </Modal>
    </section>
  );
}
