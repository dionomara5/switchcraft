"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, BookOpen, Check, CheckCircle2, ChevronRight, Clock3, LockKeyhole, NotebookPen, Search, Stethoscope, Trophy, Wrench } from "lucide-react";
import { DIAGNOSTICS, LESSONS, SHOP_NOTES, type Lesson } from "@/lib/content";
import { hasAccess } from "@/lib/access";
import type { ClientProgress } from "@/lib/api-types";
import { LockedPanel, Modal, SectionHeading } from "./ui";

interface AcademyProps {
  status: "active" | "trial" | "expired";
  progress: ClientProgress[];
  onProgressChange: (progress: ClientProgress[]) => void;
  onMembership: () => void;
  notify: (message: string, kind?: "success" | "error" | "info") => void;
}

export default function Academy({ status, progress, onProgressChange, onMembership, notify }: AcademyProps) {
  const [filter, setFilter] = useState<"all" | "foundation" | "advanced">("all");
  const [query, setQuery] = useState("");
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [answer, setAnswer] = useState<number | null>(null);
  const [quizChecked, setQuizChecked] = useState(false);
  const [saving, setSaving] = useState(false);
  const [diagnostic, setDiagnostic] = useState<(typeof DIAGNOSTICS)[number] | null>(null);
  const filtered = useMemo(() => LESSONS.filter((entry) => {
    const track = filter === "all" || (filter === "foundation" ? entry.level === "First build" : entry.level === "Advanced");
    const search = `${entry.title} ${entry.kicker} ${entry.summary}`.toLowerCase().includes(query.toLowerCase());
    return track && search;
  }), [filter, query]);
  const completed = progress.filter((entry) => entry.completed).length;

  const openLesson = (entry: Lesson) => {
    if (!hasAccess(status, entry.access)) { onMembership(); return; }
    setLesson(entry);
    setAnswer(null);
    setQuizChecked(false);
  };

  const saveCompletion = async () => {
    if (!lesson || answer !== lesson.quiz.answer) return;
    setSaving(true);
    try {
      const response = await fetch("/api/progress", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lessonId: lesson.id, completed: true, quizScore: 100 }) });
      const data = await response.json() as { progress?: ClientProgress; error?: string };
      if (!response.ok || !data.progress) throw new Error(data.error || "Could not save progress");
      const others = progress.filter((entry) => entry.lessonId !== lesson.id);
      onProgressChange([...others, data.progress]);
      notify(`${lesson.title} marked complete.`, "success");
      setLesson(null);
    } catch (error) { notify(error instanceof Error ? error.message : "Progress could not be saved.", "error"); }
    finally { setSaving(false); }
  };

  return (
    <section id="academy" className="academy-section section-pad">
      <div className="page-shell">
        <SectionHeading number="03" eyebrow="THE FIELD SCHOOL" title="Small words. Real shop knowledge." copy="Learn the idea, see the mistake, answer one useful question, then save your progress. No certificate for scrolling past a video—you complete a lesson by proving the key concept." />
        <div className="academy-dashboard">
          <div className="academy-progress"><div className="progress-ring" style={{ "--progress": `${completed / LESSONS.length * 360}deg` } as React.CSSProperties}><div><strong>{completed}</strong><span>of {LESSONS.length}</span></div></div><div><span className="eyebrow">YOUR LEARNING PATH</span><h3>{completed === LESSONS.length ? "Field school complete" : completed === 0 ? "Start with the hydraulic alphabet" : "Keep building your mental map"}</h3><p>Progress is stored with your workshop session. Quiz answers must be correct before completion is saved.</p></div></div>
          <div className="academy-stats"><div><strong>12</strong><span>authored lessons</span></div><div><strong>7</strong><span>diagnostic paths</span></div><div><strong>12</strong><span>shop notebook tips</span></div></div>
        </div>
        <div className="academy-toolbar"><div className="segmented">{(["all", "foundation", "advanced"] as const).map((item) => <button key={item} className={filter === item ? "selected" : ""} onClick={() => setFilter(item)}>{item === "all" ? "All lessons" : item === "foundation" ? "First build" : "Advanced"}</button>)}</div><label className="search-field"><Search size={16} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search lessons" /></label></div>
        <motion.div className="lesson-grid" layout>{filtered.map((entry) => {
          const done = progress.some((item) => item.lessonId === entry.id && item.completed);
          const unlocked = hasAccess(status, entry.access);
          return <motion.button layout key={entry.id} className={`lesson-card ${done ? "complete" : ""}`} onClick={() => openLesson(entry)} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} whileHover={{ y: -5 }}>
            <div className="lesson-card-top"><span>{entry.number}</span>{done ? <span className="done-badge"><Check size={13} />Complete</span> : !unlocked ? <span className="lock-badge-small"><LockKeyhole size={13} />{entry.access === "pro" ? "Member" : "Trial ended"}</span> : <span className="lesson-time"><Clock3 size={13} />{entry.minutes} min</span>}</div>
            <span className="eyebrow">{entry.kicker}</span><h3>{entry.title}</h3><p>{entry.summary}</p><div className="lesson-card-footer"><span>{entry.level}</span><span>{unlocked ? "Open lesson" : "View access"}<ChevronRight size={15} /></span></div>
          </motion.button>;
        })}</motion.div>
        {filtered.length === 0 && <div className="empty-state"><BookOpen size={30} /><h4>No lessons match that search</h4><button className="text-button" onClick={() => { setQuery(""); setFilter("all"); }}>Clear filters</button></div>}

        <div className="shop-notebook">
          <div className="subsection-heading"><div><span className="eyebrow">THE SHOP NOTEBOOK</span><h3>Tricks worth writing on the wall.</h3></div><p>Not myths. Not “secret” voltage recipes. These are the small habits that make a backyard build easier to finish, diagnose and own.</p></div>
          <div className="notes-grid">{SHOP_NOTES.map((note, index) => {
            const requirement = index < 3 ? "free" : index < 6 ? "trial" : "pro";
            const unlocked = hasAccess(status, requirement);
            return <motion.article key={note.title} className={!unlocked ? "note-locked" : ""} initial={{ opacity: 0, rotate: index % 2 ? 1 : -1, y: 25 }} whileInView={{ opacity: 1, rotate: 0, y: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ delay: (index % 4) * 0.06 }}>
              <div><span>{String(index + 1).padStart(2, "0")}</span>{!unlocked && <LockKeyhole size={16} />}</div><h4>{note.title}</h4>{unlocked ? <p>{note.body}</p> : <><p>Membership notebook entry. Complete the open lessons first, then unlock the advanced bench notes.</p><button className="text-button" onClick={onMembership}>See membership</button></>}
            </motion.article>;
          })}</div>
        </div>

        <div className="diagnostic-section">
          <div className="subsection-heading"><div><span className="eyebrow">SYMPTOM → TEST → ANSWER</span><h3>Don’t buy parts until you have evidence.</h3></div><p>Choose what the car is doing. You’ll get an ordered diagnostic path that separates control power, motor current and hydraulic flow.</p></div>
          {!hasAccess(status, "trial") ? <LockedPanel title="The diagnostic paths are workshop material" copy="The free safety lessons remain open. Membership restores all seven symptom guides and the complete build curriculum." onUnlock={onMembership} /> : <div className="diagnostic-tool"><div className="symptom-list">{DIAGNOSTICS.map((entry, index) => <button key={entry.id} className={diagnostic?.id === entry.id ? "active" : ""} onClick={() => setDiagnostic(entry)}><span>{String(index + 1).padStart(2, "0")}</span><div><strong>{entry.symptom}</strong><small>Start here</small></div><ArrowRight size={16} /></button>)}</div><div className="diagnostic-answer"><AnimatePresence mode="wait">{diagnostic ? <motion.div key={diagnostic.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -15 }}><span className="eyebrow">FIRST AREA TO INVESTIGATE</span><h4>{diagnostic.likely}</h4><ol>{diagnostic.steps.map((step, index) => <li key={step}><span>{index + 1}</span><p>{step}</p></li>)}</ol><div className="inline-callout"><Stethoscope size={18} /><p>Record the reading and change one thing at a time. Isolate power before continuity or resistance tests, and stop for heat, smoke, sticking or unexpected movement.</p></div></motion.div> : <motion.div className="diagnostic-empty" key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }}><Wrench size={35} /><h4>Pick the symptom, not a replacement part.</h4><p>The ordered tests will appear here.</p></motion.div>}</AnimatePresence></div></div>}
        </div>
      </div>

      <Modal open={Boolean(lesson)} onClose={() => setLesson(null)} title={lesson?.title ?? "Lesson"} eyebrow={lesson ? `${lesson.number} · ${lesson.kicker} · ${lesson.minutes} MIN` : undefined} wide>
        {lesson && <div className="lesson-reader"><div className="lesson-reader-intro"><BookOpen size={24} /><p>{lesson.summary}</p></div>{lesson.sections.map((section, index) => <section key={section.heading}><span>{String(index + 1).padStart(2, "0")}</span><div><h4>{section.heading}</h4><p>{section.body}</p>{section.bullets && <ul>{section.bullets.map((bullet) => <li key={bullet}><CheckCircle2 size={15} />{bullet}</li>)}</ul>}</div></section>)}<aside className="field-tip"><NotebookPen size={22} /><div><span className="eyebrow">WRITE THIS ONE DOWN</span><p>{lesson.fieldTip}</p></div></aside><section className="lesson-quiz"><span className="eyebrow">ONE-QUESTION KNOWLEDGE CHECK</span><h4>{lesson.quiz.question}</h4><div>{lesson.quiz.options.map((option, index) => <button key={option} className={quizChecked ? index === lesson.quiz.answer ? "correct" : answer === index ? "incorrect" : "" : answer === index ? "selected" : ""} onClick={() => { setAnswer(index); setQuizChecked(false); }}><span>{String.fromCharCode(65 + index)}</span>{option}{quizChecked && index === lesson.quiz.answer && <Check size={16} />}</button>)}</div>{answer === null ? <p>Select an answer to check your understanding.</p> : !quizChecked ? <button className="button button-dark" onClick={() => setQuizChecked(true)}>Check answer</button> : <motion.div className={`answer-explanation ${answer === lesson.quiz.answer ? "correct" : "incorrect"}`} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}><strong>{answer === lesson.quiz.answer ? "That’s it." : "Not quite—read the correct answer, then choose it to finish."}</strong><p>{lesson.quiz.explanation}</p></motion.div>}</section><div className="lesson-complete-bar"><div><Trophy size={20} /><span>{progress.some((entry) => entry.lessonId === lesson.id && entry.completed) ? "Already completed—review anytime" : "Answer correctly to save completion"}</span></div><button className="button button-acid" disabled={!quizChecked || answer !== lesson.quiz.answer || saving} onClick={saveCompletion}>{saving ? "Saving…" : "Mark lesson complete"}<ArrowRight size={16} /></button></div></div>}
      </Modal>
    </section>
  );
}
