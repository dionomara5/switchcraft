"use client";

import { useRef } from "react";
import { motion, useReducedMotion, useScroll, useTransform } from "framer-motion";
import { ArrowDown, ArrowRight, CircuitBoard, MousePointer2 } from "lucide-react";

export default function Hero() {
  const ref = useRef<HTMLElement>(null);
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const imageY = useTransform(scrollYProgress, [0, 1], [0, reduceMotion ? 0 : 170]);
  const imageScale = useTransform(scrollYProgress, [0, 1], [1.04, reduceMotion ? 1.04 : 1.24]);
  const contentY = useTransform(scrollYProgress, [0, 1], [0, reduceMotion ? 0 : -95]);
  const contentOpacity = useTransform(scrollYProgress, [0, 0.82], [1, 0]);
  const overlayOpacity = useTransform(scrollYProgress, [0, 1], [0.3, 0.85]);
  const lines = ["BUILT BY", "YOUR OWN", "TWO HANDS."];
  return (
    <section ref={ref} className="hero" id="top">
      <motion.div className="hero-media" style={{ y: imageY, scale: imageScale }}>
        <img src="https://images.pexels.com/photos/17075786/pexels-photo-17075786.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=2000" alt="Classic Chevrolet Impala lowrider at a car show" fetchPriority="high" />
      </motion.div>
      <motion.div className="hero-shade" style={{ opacity: overlayOpacity }} />
      <div className="hero-grid" />
      <svg className="hero-circuit" viewBox="0 0 700 700" aria-hidden="true"><path d="M40 350H180L260 270H410L490 190H660" /><path d="M40 410H210L290 490H455L535 570H660" /><path d="M180 350V510H95" /><path d="M490 190V70H600" /><circle cx="40" cy="350" r="8" /><circle cx="40" cy="410" r="8" /><circle cx="660" cy="190" r="8" /><circle cx="660" cy="570" r="8" /><circle cx="95" cy="510" r="8" /><circle cx="600" cy="70" r="8" /></svg>
      <motion.div className="hero-content page-shell" style={{ y: contentY, opacity: contentOpacity }}>
        <motion.div className="hero-kicker" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25, duration: 0.6 }}><CircuitBoard size={17} /><span>THE LOWRIDER HYDRAULIC FIELD SCHOOL</span><span className="hero-edition">EST. IN THE GARAGE</span></motion.div>
        <h1>{lines.map((line, index) => <span className="headline-mask" key={line}><motion.span initial={{ y: "110%" }} animate={{ y: 0 }} transition={{ delay: 0.18 + index * 0.12, duration: 0.9, ease: [0.16, 1, 0.3, 1] }}>{line}</motion.span></span>)}</h1>
        <div className="hero-bottom">
          <motion.div className="hero-intro" initial={{ opacity: 0, y: 25 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.72, duration: 0.7 }}><p>Step-by-step 2, 4, 6 and 8-pump plans for any car from 1920 to today. Color-coded wiring. Switch boxes from scratch. A parts list you can actually use.</p><div className="hero-actions"><a className="button button-acid" href="#studio">Plan my setup<ArrowRight size={18} /></a><a className="button button-glass" href="#wire-lab">Learn the switches<MousePointer2 size={17} /></a></div></motion.div>
          <motion.dl className="hero-stats" initial={{ opacity: 0, x: 35 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.85, duration: 0.7 }}><div><dt>PUMP FAMILIES</dt><dd>2 · 4 · 6 · 8</dd></div><div><dt>VEHICLE YEARS</dt><dd>1920—{new Date().getFullYear()}</dd></div><div><dt>TRY THE WORKSHOP</dt><dd>5 days</dd></div></motion.dl>
        </div>
      </motion.div>
      <motion.a className="hero-scroll" href="#assembly" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.25 }}><span>SCROLL TO ASSEMBLE</span><ArrowDown size={16} /></motion.a>
      <div className="hero-wire hero-wire-one" /><div className="hero-wire hero-wire-two" />
    </section>
  );
}
