export type AccessRequirement = "free" | "trial" | "pro";
export type AccessStatus = "active" | "trial" | "expired";

export function hasAccess(status: AccessStatus, requirement: AccessRequirement) {
  if (requirement === "free") return true;
  if (requirement === "trial") return status === "active" || status === "trial";
  return status === "active";
}
