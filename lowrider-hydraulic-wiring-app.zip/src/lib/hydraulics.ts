export type PumpCount = 2 | 4 | 6 | 8;
export type BuildTier = "backyard" | "street" | "show";
export type ControlLayout = "fb" | "fbss" | "fbcc" | "independent";
export type Corner = "FL" | "FR" | "RL" | "RR";
export type BoostedAxle = "front" | "rear";
export type SwitchBoxSize = 2 | 4 | 6 | 10;

export interface BuildConfig {
  vehicleYear: number;
  vehicleMake: string;
  vehicleModel: string;
  pumpCount: PumpCount;
  layout: ControlLayout;
  boostedAxle: BoostedAxle;
  tier: BuildTier;
  motorVoltage: 12 | 24 | 36 | 48 | 60 | 72;
  controlVoltage: 12 | 24;
  batteryCount: number;
  frontCylinder: 6 | 8 | 10 | 12;
  rearCylinder: 6 | 8 | 10 | 12 | 14;
  accumulators: boolean;
  switchBox: SwitchBoxSize;
}

export interface Circuit {
  id: Corner;
  name: string;
  pumpIds: number[];
  dumpId: string;
  sharedDump?: boolean;
}

export interface HydraulicCommand {
  id: string;
  label: string;
  shortLabel: string;
  upChannels: string[];
  downChannels: string[];
  upPumpIds: number[];
  downDumpIds: string[];
  description: string;
}

export interface WireSpec {
  id: string;
  function: string;
  colorName: string;
  color: string;
  destination: string;
  kind: "control" | "pump" | "dump";
}

export interface BomItem {
  id: string;
  category: string;
  name: string;
  quantity: number;
  unit: string;
  note: string;
  low: number;
  high: number;
}

export const CORNER_NAMES: Record<Corner, string> = {
  FL: "Front left",
  FR: "Front right",
  RL: "Rear left",
  RR: "Rear right",
};

export const WIRE_COLORS = {
  red: "#ff5252",
  black: "#87919e",
  brown: "#c58b5c",
  purple: "#bd8cff",
  blue: "#4aa8ff",
  orange: "#ff963f",
  yellow: "#f7d54d",
  green: "#42db8b",
  white: "#f4f2ea",
};

export const DEFAULT_CONFIG: BuildConfig = {
  vehicleYear: 1964,
  vehicleMake: "Chevrolet",
  vehicleModel: "Impala",
  pumpCount: 2,
  layout: "fbss",
  boostedAxle: "front",
  tier: "backyard",
  motorVoltage: 48,
  controlVoltage: 24,
  batteryCount: 4,
  frontCylinder: 8,
  rearCylinder: 10,
  accumulators: true,
  switchBox: 4,
};

export function getLayoutOptions(pumpCount: PumpCount) {
  if (pumpCount === 2) {
    return [
      { id: "fb" as const, name: "Front / Back", detail: "2 pumps · 2 axle dumps · simplest plumbing" },
      { id: "fbss" as const, name: "FBSS", detail: "2 pumps · 4 dumps · individual corner drop" },
      { id: "fbcc" as const, name: "FBCC rear", detail: "2 pumps · 3 dumps · independent rear corners" },
    ];
  }
  return [
    { id: "independent" as const, name: "Four-corner independent", detail: `${pumpCount} pumps · 4 corner circuits · 4 dumps` },
  ];
}

export function getCircuits(config: BuildConfig): Circuit[] {
  const corners: Corner[] = ["FL", "FR", "RL", "RR"];
  if (config.pumpCount === 2) {
    return corners.map((corner) => {
      const isFront = corner.startsWith("F");
      const sharedDump = config.layout === "fb" || (config.layout === "fbcc" && isFront);
      return {
        id: corner,
        name: CORNER_NAMES[corner],
        pumpIds: [isFront ? 1 : 2],
        dumpId: sharedDump ? (isFront ? "D-F" : "D-R") : `D-${corner}`,
        sharedDump,
      };
    });
  }

  if (config.pumpCount === 4) {
    return corners.map((corner, index) => ({
      id: corner,
      name: CORNER_NAMES[corner],
      pumpIds: [index + 1],
      dumpId: `D-${corner}`,
    }));
  }

  if (config.pumpCount === 6) {
    const assignments: Record<Corner, number[]> = config.boostedAxle === "front"
      ? { FL: [1, 2], FR: [3, 4], RL: [5], RR: [6] }
      : { FL: [1], FR: [2], RL: [3, 4], RR: [5, 6] };
    return corners.map((corner) => ({
      id: corner,
      name: CORNER_NAMES[corner],
      pumpIds: assignments[corner],
      dumpId: `D-${corner}`,
    }));
  }

  return corners.map((corner, index) => ({
    id: corner,
    name: CORNER_NAMES[corner],
    pumpIds: [index * 2 + 1, index * 2 + 2],
    dumpId: `D-${corner}`,
  }));
}

function unique(values: string[]) {
  return [...new Set(values)];
}

function circuitChannels(circuits: Circuit[], selected: Corner[]) {
  return unique(circuits.filter((circuit) => selected.includes(circuit.id)).map((circuit) => circuit.pumpIds.join("+")));
}

function pumpIds(circuits: Circuit[], selected: Corner[]) {
  return unique(circuits.filter((circuit) => selected.includes(circuit.id)).flatMap((circuit) => circuit.pumpIds.map(String))).map(Number);
}

function dumpIds(circuits: Circuit[], selected: Corner[]) {
  return unique(circuits.filter((circuit) => selected.includes(circuit.id)).map((circuit) => circuit.dumpId));
}

export function getCommands(config: BuildConfig): HydraulicCommand[] {
  const circuits = getCircuits(config);
  const independentLift = config.pumpCount > 2;
  const make = (
    id: string,
    label: string,
    shortLabel: string,
    upCorners: Corner[],
    downCorners: Corner[],
    description: string,
    allowIndependentUp = true,
  ): HydraulicCommand => {
    const effectiveUp = allowIndependentUp || independentLift ? upCorners : [];
    return {
      id,
      label,
      shortLabel,
      upChannels: circuitChannels(circuits, effectiveUp),
      downChannels: dumpIds(circuits, downCorners),
      upPumpIds: pumpIds(circuits, effectiveUp),
      downDumpIds: dumpIds(circuits, downCorners),
      description,
    };
  };

  return [
    make("front", "Front", "FRONT", ["FL", "FR"], ["FL", "FR"], "Raise the front pumps together; dump both front corners."),
    make("rear", "Rear", "REAR", ["RL", "RR"], ["RL", "RR"], "Raise the rear pumps together; dump both rear corners."),
    make("left", "Left side", "LEFT", ["FL", "RL"], ["FL", "RL"], independentLift ? "Lift or drop the left side as a pair." : "Drops both left corners. A two-pump system cannot lift one side independently."),
    make("right", "Right side", "RIGHT", ["FR", "RR"], ["FR", "RR"], independentLift ? "Lift or drop the right side as a pair." : "Drops both right corners. A two-pump system cannot lift one side independently."),
    make("fl", "Front left corner", "FL", ["FL"], ["FL"], "Individual front-left corner control."),
    make("fr", "Front right corner", "FR", ["FR"], ["FR"], "Individual front-right corner control."),
    make("rl", "Rear left corner", "RL", ["RL"], ["RL"], "Individual rear-left corner control."),
    make("rr", "Rear right corner", "RR", ["RR"], ["RR"], "Individual rear-right corner control."),
    make("pancake", "Pancake", "ALL", ["FL", "FR", "RL", "RR"], ["FL", "FR", "RL", "RR"], "Raises every corner together or dumps every corner together."),
    make("seesaw", "See-saw", "SEE-SAW", ["FL", "FR"], ["RL", "RR"], "Lifts the front while dumping the rear. Use only in a safe, stationary test area."),
  ];
}

export function getBoxCommands(config: BuildConfig, size = config.switchBox) {
  const commands = getCommands(config);
  const order = size === 2
    ? ["front", "rear"]
    : size === 4
      ? ["front", "rear", "left", "right"]
      : size === 6
        ? ["front", "rear", "left", "right", "rl", "rr"]
        : ["front", "rear", "left", "right", "fl", "fr", "rl", "rr", "pancake", "seesaw"];
  return order.map((id) => commands.find((command) => command.id === id)!).filter(Boolean);
}

export function getSwitchSpec(command: HydraulicCommand) {
  const poles = Math.max(command.upChannels.length, command.downChannels.length, 1);
  const prongs = poles === 1 ? 3 : poles === 2 ? 6 : 12;
  return { poles, prongs, type: prongs === 3 ? "SPDT" : prongs === 6 ? "DPDT" : "4PDT" };
}

export function getWireMap(config: BuildConfig): WireSpec[] {
  const circuits = getCircuits(config);
  const independent = config.pumpCount > 2;
  const pumpWires: WireSpec[] = independent
    ? [
        { id: "P-FL", function: "Front-left pump trigger", colorName: "Black", color: WIRE_COLORS.black, destination: `P${circuits[0].pumpIds.join(" + P")} solenoid S terminals`, kind: "pump" },
        { id: "P-FR", function: "Front-right pump trigger", colorName: "Brown", color: WIRE_COLORS.brown, destination: `P${circuits[1].pumpIds.join(" + P")} solenoid S terminals`, kind: "pump" },
        { id: "P-RL", function: "Rear-left pump trigger", colorName: "Purple", color: WIRE_COLORS.purple, destination: `P${circuits[2].pumpIds.join(" + P")} solenoid S terminals`, kind: "pump" },
        { id: "P-RR", function: "Rear-right pump trigger", colorName: "Blue", color: WIRE_COLORS.blue, destination: `P${circuits[3].pumpIds.join(" + P")} solenoid S terminals`, kind: "pump" },
      ]
    : [
        { id: "P-F", function: "Front pump trigger", colorName: "Black", color: WIRE_COLORS.black, destination: "P1 solenoid S terminals", kind: "pump" },
        { id: "P-R", function: "Rear pump trigger", colorName: "Blue", color: WIRE_COLORS.blue, destination: "P2 solenoid S terminals", kind: "pump" },
      ];

  const dumpColors = [
    { name: "Orange", hex: WIRE_COLORS.orange },
    { name: "Yellow", hex: WIRE_COLORS.yellow },
    { name: "Green", hex: WIRE_COLORS.green },
    { name: "White", hex: WIRE_COLORS.white },
  ];
  const dumps = unique(circuits.map((circuit) => circuit.dumpId));
  const dumpWires = dumps.map((dumpId, index) => {
    const owners = circuits.filter((circuit) => circuit.dumpId === dumpId).map((circuit) => circuit.name.toLowerCase()).join(" + ");
    return {
      id: dumpId,
      function: `${dumpId} dump trigger`,
      colorName: dumpColors[index].name,
      color: dumpColors[index].hex,
      destination: `${dumpId} dump coil (${owners})`,
      kind: "dump" as const,
    };
  });

  return [
    { id: "CONTROL", function: `${config.controlVoltage}V switched control feed`, colorName: "Red", color: WIRE_COLORS.red, destination: `Fused ${config.controlVoltage}V tap to every switch common`, kind: "control" },
    ...pumpWires,
    ...dumpWires,
  ];
}

export function getBatteryPlan(config: BuildConfig) {
  const series = config.motorVoltage / 12;
  const strings = Math.max(1, Math.round(config.batteryCount / series));
  return {
    series,
    strings,
    total: series * strings,
    controlBatteries: config.controlVoltage / 12,
    description: `${strings} matched ${series}-battery string${strings > 1 ? "s" : ""} in parallel · ${config.motorVoltage}V motor bus`,
  };
}

export function getBom(config: BuildConfig): BomItem[] {
  const circuits = getCircuits(config);
  const dumps = unique(circuits.map((circuit) => circuit.dumpId)).length;
  const solenoidsPerPump = config.tier === "backyard" ? 2 : 3;
  const boxCommands = getBoxCommands(config);
  const threeProng = boxCommands.filter((command) => getSwitchSpec(command).prongs === 3).length;
  const sixProng = boxCommands.filter((command) => getSwitchSpec(command).prongs === 6).length;
  const twelveProng = boxCommands.filter((command) => getSwitchSpec(command).prongs === 12).length;
  const wireCount = getWireMap(config).length;
  const finishMultiplier = config.tier === "show" ? 1.7 : config.tier === "street" ? 1.25 : 1;
  const item = (id: string, category: string, name: string, quantity: number, unit: string, note: string, low: number, high: number): BomItem => ({
    id, category, name, quantity, unit, note, low: Math.round(low * finishMultiplier), high: Math.round(high * finishMultiplier),
  });

  return [
    item("pump", "Hydraulics", "Pump head, tank, block & motor assemblies", config.pumpCount, "assembly", `${config.pumpCount > 4 ? "Paired circuits need one checked pressure outlet per pump." : "Match gear size, port size and motor rating."}`, 260 * config.pumpCount, 520 * config.pumpCount),
    item("dump", "Hydraulics", "Dump cartridges with coils", dumps, "dump", `${dumps} electrical dump channels; match coil voltage to ${config.controlVoltage}V control supply.`, 65 * dumps, 150 * dumps),
    item("solenoid", "Electrical", "High-current motor solenoids", config.pumpCount * solenoidsPerPump, "solenoid", `${solenoidsPerPump} per pump for this ${config.tier} plan; use identical rated units per bank.`, 18 * config.pumpCount * solenoidsPerPump, 42 * config.pumpCount * solenoidsPerPump),
    item("cylinder-front", "Suspension", `${config.frontCylinder}-inch front cylinders`, 2, "cylinder", "Final length depends on measured collapsed height, cups and desired travel.", 115 * 2, 240 * 2),
    item("cylinder-rear", "Suspension", `${config.rearCylinder}-inch rear cylinders`, 2, "cylinder", "Check driveshaft engagement and rear-end travel before choosing stroke.", 115 * 2, 250 * 2),
    item("battery", "Electrical", "Matched 12V deep-cycle batteries", config.batteryCount, "battery", getBatteryPlan(config).description, 110 * config.batteryCount, 230 * config.batteryCount),
    item("switch", "Controls", "3-prong momentary switches", threeProng, "switch", "Single-pole up/off/down circuits.", 9 * threeProng, 18 * threeProng),
    item("switch", "Controls", "6-prong momentary switches", sixProng, "switch", "Two-pole up/off/down circuits.", 11 * sixProng, 24 * sixProng),
    item("switch", "Controls", "12-prong momentary switches", twelveProng, "switch", "Four-pole combination controls; confirm terminal map by meter.", 24 * twelveProng, 48 * twelveProng),
    item("switch-cord", "Controls", `${wireCount}-conductor switch cord`, 17, "foot", `${wireCount} used conductors plus spare conductors are recommended; 18 AWG control cord.`, 28, 55),
    item("check-valve", "Hydraulics", "Rated pump check valves", config.pumpCount, "valve", "One per pump outlet prevents a paired pump from back-feeding another.", 18 * config.pumpCount, 45 * config.pumpCount),
    item("hose", "Hydraulics", "Rated pressure hose / hard-line sets", 4, "corner line", "Route away from heat and sharp edges; pressure rating must exceed pump relief setting.", 45 * 4, 110 * 4),
    item("accumulator", "Ride & safety", "Nitrogen accumulators", config.accumulators ? 4 : 0, "accumulator", config.accumulators ? "One per corner for a more compliant street ride." : "Not selected. Expect a firmer ride and greater shock loads.", 0, config.accumulators ? 180 * 4 : 0),
    item("cable", "Electrical", "Fine-strand battery cable & lugs", Math.max(20, config.batteryCount * 4 + config.pumpCount * 3), "foot", "Size by current and total run; protect every positive run from chafing.", 75, 220),
    item("rack", "Fabrication", "Frame-supported rack & battery hold-downs", 1, "set", "Fabrication is not included in vendor kit pricing. Remove fuel tank before nearby welding.", 250, 1100),
    item("disconnect", "Electrical", "Rated service disconnect, fuses & terminal block", 1, "set", "Provides a serviceable isolation point and labeled switch-cord landing point.", 85, 240),
  ].filter((entry) => entry.quantity > 0);
}

export function getBuildSummary(config: BuildConfig) {
  const circuits = getCircuits(config);
  const dumps = unique(circuits.map((circuit) => circuit.dumpId)).length;
  const bom = getBom(config);
  return {
    circuits,
    dumps,
    solenoids: config.pumpCount * (config.tier === "backyard" ? 2 : 3),
    conductors: getWireMap(config).length,
    low: bom.reduce((sum, entry) => sum + entry.low, 0),
    high: bom.reduce((sum, entry) => sum + entry.high, 0),
    battery: getBatteryPlan(config),
  };
}

export function normalizeConfig(input: Partial<BuildConfig> | null | undefined): BuildConfig {
  const merged = { ...DEFAULT_CONFIG, ...(input ?? {}) };
  const pumpCount = ([2, 4, 6, 8].includes(Number(merged.pumpCount)) ? Number(merged.pumpCount) : 2) as PumpCount;
  const motorVoltage = ([12, 24, 36, 48, 60, 72].includes(Number(merged.motorVoltage)) ? Number(merged.motorVoltage) : 48) as BuildConfig["motorVoltage"];
  const series = motorVoltage / 12;
  const requestedBatteries = Math.min(24, Math.max(series, Number(merged.batteryCount) || series));
  const requestedStrings = Math.max(1, Math.min(4, Math.round(requestedBatteries / series)));
  const batteryCount = series * requestedStrings;
  const layout = pumpCount === 2 && ["fb", "fbss", "fbcc"].includes(merged.layout) ? merged.layout : pumpCount === 2 ? "fbss" : "independent";
  return {
    ...DEFAULT_CONFIG,
    ...merged,
    vehicleYear: Math.min(new Date().getFullYear(), Math.max(1920, Number(merged.vehicleYear) || 1964)),
    vehicleMake: String(merged.vehicleMake || "Chevrolet").slice(0, 40),
    vehicleModel: String(merged.vehicleModel || "Impala").slice(0, 60),
    pumpCount,
    layout,
    motorVoltage,
    batteryCount,
    controlVoltage: Number(merged.controlVoltage) === 12 || motorVoltage === 12 ? 12 : 24,
    switchBox: ([2, 4, 6, 10].includes(Number(merged.switchBox)) ? Number(merged.switchBox) : 4) as SwitchBoxSize,
  };
}

export function getInstallSteps(config: BuildConfig) {
  const summary = getBuildSummary(config);
  const wires = getWireMap(config);
  return [
    { title: "Measure the car before buying metal", detail: `Support the ${config.vehicleYear} ${config.vehicleMake} ${config.vehicleModel} on rated stands. Record collapsed spring-pocket height, full steering travel, suspension travel and trunk rack space. Choose cylinder stroke from measurements—not from another car's parts list.`, check: "Four corner measurements, wheel clearance and rack dimensions recorded." },
    { title: "Make the structure ready", detail: "Inspect the frame, spring pockets, control arms and rear housing. Have a qualified fabricator design reinforcement and rack mounts. Remove the fuel tank and protect wiring/interior before welding. Never rely on thin trunk sheet metal to carry the battery rack.", check: "No rust-through, cracked mounts or unresolved steering/driveline interference." },
    { title: "Bench-build the power rack", detail: `Arrange ${config.batteryCount} matched batteries as ${summary.battery.description}. Install hold-downs, insulated terminal covers, the service disconnect and ${config.pumpCount} pump assemblies. Keep filler caps accessible and leave room to tighten every connection.`, check: "Nothing moves by hand; every terminal is covered and every pump can be serviced." },
    { title: "Plumb one corner at a time", detail: `Build ${summary.circuits.length} corner circuits with ${summary.dumps} dump channels. Each pump outlet gets its own rated check valve before any paired lines join. Use pressure-rated hose or hard line, correct fittings and a clean deburring/flushing process.`, check: "Every line is labeled FL, FR, RL or RR at both ends; no pump outlet back-feeds another." },
    { title: "Land the high-current power", detail: `Connect each series string negative-to-positive, then parallel only identical strings at common bus points. Feed each motor through its own ${config.tier === "backyard" ? "two" : "three"}-solenoid bank sized for the motor current. Keep cable runs short, supported and protected from sharp metal.`, check: `${config.motorVoltage}V measured at the motor bus and polarity verified before motors are connected.` },
    { title: "Wire the switch box on the bench", detail: `Use the ${wires.length}-conductor reference map. Red feeds switch commons through a correctly rated control fuse; pump-trigger wires land on the raise contacts and dump-trigger wires on the lower contacts. The drawing is viewed from the wiring side with switch notches up—verify your actual switch with continuity.`, check: "Every common, raise and lower contact passes a meter test before power is attached." },
    { title: "Test with wheels supported", detail: `Reconnect the service disconnect with the car securely supported. Test one dump, then one pump at a time at low energy. Confirm the labeled corner is the corner that moves. Never place any part of your body beneath a car supported only by hydraulics.`, check: "All four corner labels match actual movement; no hot cables, stuck solenoids or leaks." },
    { title: "Set ride, then recheck everything", detail: "Lower onto mechanical stands before inspecting fittings. Set slow-downs gradually, verify hose clearance through full travel, check driveshaft engagement and charge each battery string with compatible equipment. Re-torque after the first short test session.", check: "No leaks, balanced battery voltages, full steering clearance and a written recheck date." },
  ];
}
