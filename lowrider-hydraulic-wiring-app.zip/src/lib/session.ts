import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { members, type Member } from "@/db/schema";

export const SESSION_COOKIE = "switchcraft_session";
export const TRIAL_DAYS = 5;

export { hasAccess } from "./access";
export type { AccessRequirement } from "./access";

export function publicMember(member: Member) {
  const now = Date.now();
  const trialEnd = new Date(member.trialEndsAt).getTime();
  const status = member.status === "active" ? "active" : trialEnd > now ? "trial" : "expired";
  return {
    id: member.id,
    status: status as "active" | "trial" | "expired",
    trialEndsAt: member.trialEndsAt,
    createdAt: member.createdAt,
    daysLeft: status === "trial" ? Math.max(0, Math.ceil((trialEnd - now) / 86_400_000)) : status === "active" ? null : 0,
  };
}

export async function getMemberFromCookies() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const [member] = await db.select().from(members).where(eq(members.sessionToken, token)).limit(1);
  return member ?? null;
}

export async function requireMember() {
  const member = await getMemberFromCookies();
  if (!member) throw new Error("NO_SESSION");
  return member;
}

export async function createMember(token: string) {
  const trialEndsAt = new Date(Date.now() + TRIAL_DAYS * 86_400_000);
  const [member] = await db.insert(members).values({ sessionToken: token, trialEndsAt }).returning();
  return member;
}
