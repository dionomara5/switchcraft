import type { BuildConfig } from "./hydraulics";

export interface ClientBuild {
  id: string;
  name: string;
  config: BuildConfig;
  updatedAt: string;
}

export interface ClientProgress {
  lessonId: string;
  completed: boolean;
  quizScore: number;
}

export interface ClientShoppingItem {
  productId: string;
  quantity: number;
}

export interface SessionPayload {
  member: {
    id: string;
    status: "active" | "trial" | "expired";
    trialEndsAt: string;
    createdAt: string;
    daysLeft: number | null;
  };
  builds: ClientBuild[];
  progress: ClientProgress[];
  shopping: ClientShoppingItem[];
}
