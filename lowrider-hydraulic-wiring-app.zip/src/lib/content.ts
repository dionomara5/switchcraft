import type { AccessRequirement } from "./access";

export interface LessonSection {
  heading: string;
  body: string;
  bullets?: string[];
}

export interface Lesson {
  id: string;
  number: string;
  title: string;
  kicker: string;
  level: "First build" | "Street" | "Advanced";
  access: AccessRequirement;
  minutes: number;
  summary: string;
  sections: LessonSection[];
  fieldTip: string;
  quiz: { question: string; options: string[]; answer: number; explanation: string };
}

export const ERA_GUIDES = [
  { range: [1920, 1929], title: "The pioneering chassis", electrical: "Many vehicles use 6V electrics; some early vehicles have very minimal wiring.", structure: "Separate chassis construction varies widely and body structures may include wood.", plan: "Treat this as a custom chassis project. Document original brakes, steering and frame strength before designing suspension travel.", warning: "Do not use the original 6V system as a hydraulic power source. Keep a separately fused, correctly rated hydraulic battery system." },
  { range: [1930, 1939], title: "Separate-frame classics", electrical: "6V systems remain common; generator and original wiring capacity are limited.", structure: "A separate frame helps rack planning, but old rivets, repairs and rust need close inspection.", plan: "Measure solid-axle clearance and suspension travel through steering. A custom four-corner mounting design is usually required.", warning: "Old brake and steering systems need their own safety review before the car is driven." },
  { range: [1940, 1949], title: "Pre-war & post-war steel", electrical: "Many original systems are still 6V, with later transitions depending on make and model.", structure: "Full frames are common, but decades of patches can hide weak mounting areas.", plan: "Map fuel tank, exhaust and rear-axle movement before locating cylinders or cutting a trunk floor.", warning: "Never weld near an installed fuel tank. Removal and professional fabrication are the safe plan." },
  { range: [1950, 1959], title: "The 12V transition", electrical: "Many US makes moved from 6V to 12V during this decade; verify the actual car, not just its year.", structure: "Frame shapes vary significantly. Late-1950s GM X-frame cars need model-specific reinforcement planning.", plan: "Record front spring-pocket dimensions and rear axle type. Keep original lighting and charging circuits isolated from hydraulic power.", warning: "A 1958–1964 X-frame should not be treated like a perimeter-frame car." },
  { range: [1960, 1969], title: "The classic lowrider era", electrical: "12V negative-ground systems are common, but previous owners may have altered wiring.", structure: "Body-on-frame layouts and large spring pockets make many models adaptable; X-frame and perimeter-frame rules differ.", plan: "Confirm frame family before buying preformed reinforcement. Mock up cylinders with springs removed and suspension safely supported.", warning: "Popular does not mean universal: an Impala kit can differ across generations." },
  { range: [1970, 1979], title: "Big-body weight & travel", electrical: "12V systems are standard; added accessories may already load the cabin wiring.", structure: "Long, heavy bodies place substantial load on mounts, cups and rear suspension.", plan: "Account for vehicle mass, long hose runs, trunk rack weight and driveline travel. Measure twice at full suspension compression.", warning: "Rear cylinder stroke can change driveshaft engagement. Verify it before driving." },
  { range: [1980, 1989], title: "G-bodies & mini trucks", electrical: "12V fused accessories are typical; route new control power separately from factory circuits.", structure: "G-body frames and mini-truck chassis have well-known but generation-specific packaging constraints.", plan: "Check bed/trunk space, fuel tank location, frame narrowing and rear axle movement before selecting a rack.", warning: "Do not assume every G-body or every mini-truck shares cup, coil or rack dimensions." },
  { range: [1990, 1999], title: "Perimeter frames & early electronics", electrical: "More factory electronics appear; keep hydraulic noise and current away from sensitive modules.", structure: "B-bodies remain separate-frame while many other cars are unibody and need a different engineering approach.", plan: "Identify frame type first. Avoid drilling near factory brake/fuel lines and airbag wiring.", warning: "Unibody reinforcement is not a universal bolt-on recipe; use a qualified chassis designer." },
  { range: [2000, 2009], title: "ABS, modules & tight packaging", electrical: "ABS, body modules and multiplexed circuits require careful routing and clean independent power.", structure: "Mixed unibody and body-on-frame platforms; crumple zones and module locations matter.", plan: "Scan for factory equipment before cutting. Preserve brake lines, restraint systems and service access.", warning: "Never piggyback high-current hydraulic loads onto factory accessory wiring." },
  { range: [2010, 2019], title: "Networked vehicles", electrical: "CAN networks, battery monitoring and extensive driver-assistance equipment are common.", structure: "High-strength steel and engineered crush paths can change safe fabrication locations.", plan: "Obtain service information for welding and battery isolation. Keep factory 12V battery management unchanged unless a specialist specifies otherwise.", warning: "Welding can damage modules. Follow manufacturer isolation procedures and use a qualified fabricator." },
  { range: [2020, 2026], title: "ADAS & electrification", electrical: "ADAS, 48V subsystems and high-voltage EV architecture may be present.", structure: "Mixed materials, structural battery enclosures and high-strength panels demand model-specific review.", plan: "Confirm platform and powertrain before planning. Calibration, lifting points and approved repair procedures matter.", warning: "Never tap, cut or weld near orange high-voltage EV cabling or a structural traction battery." },
] as const;

export const VEHICLE_PROFILES = [
  { make: "Ford", model: "Model A", years: "1928–1931", note: "Plan a fully custom cylinder and rack package around the original chassis; preserve and inspect mechanical/braking upgrades separately." },
  { make: "Chevrolet", model: "Master", years: "1933–1936", note: "A separate frame helps mounting, but original 6V electrics and aged structure call for an isolated power system and thorough inspection." },
  { make: "Ford", model: "Deluxe", years: "1940–1948", note: "Mock up axle and suspension travel carefully; frame repairs and previous customization determine where reinforcement can go." },
  { make: "Chevrolet", model: "Fleetline", years: "1949–1952", note: "Confirm the electrical conversion status and fuel-system location before designing the trunk rack." },
  { make: "Chevrolet", model: "Bel Air", years: "1955–1957", note: "Tri-five frame and spring-pocket dimensions differ from later Impalas; use measurements rather than later-model kit assumptions." },
  { make: "Chevrolet", model: "Impala", years: "1958–1964", note: "Identify the X-frame and use reinforcement designed for that structure. Do not substitute perimeter-frame instructions." },
  { make: "Chevrolet", model: "Impala", years: "1965–1970", note: "The perimeter-frame generation has different reinforcement and rack patterns from 1958–1964 cars." },
  { make: "Chevrolet", model: "Caprice", years: "1971–1976", note: "Account for big-body mass, rear suspension travel and trunk rack loading when sizing parts." },
  { make: "Cadillac", model: "Fleetwood", years: "1977–1996", note: "Check exact generation: downsized RWD, later B/D-body and other Fleetwood variants are not one fitment." },
  { make: "Chevrolet", model: "Monte Carlo", years: "1978–1988", note: "G-body frame, cup and rear-suspension details vary by year; verify control-arm and frame reinforcement." },
  { make: "Buick", model: "Regal", years: "1978–1987", note: "Shares G-body concepts with related models, but measure the actual chassis and previous repairs before ordering." },
  { make: "Oldsmobile", model: "Cutlass", years: "1978–1988", note: "Confirm G-body generation and rear suspension geometry; do not order by model name alone." },
  { make: "Chevrolet", model: "S-10", years: "1982–2004", note: "Mini-truck bed rack, fuel tank, axle travel and possible frame work require a different package from a full-size car." },
  { make: "Lincoln", model: "Town Car", years: "1980–2011", note: "Panther-platform generations share ideas but still need year-specific rear suspension and electronics checks." },
  { make: "Chevrolet", model: "Impala SS", years: "1994–1996", note: "B-body packaging is friendly to planning, but preserve factory electronics and verify existing frame modifications." },
  { make: "Chrysler", model: "300", years: "2005–present", note: "Modern electronics, high-strength structures and suspension geometry require model-specific engineering rather than a classic-car template." },
  { make: "Tesla", model: "any", years: "2012–present", note: "High-voltage battery and structural restrictions make this a specialist-only platform; never improvise around orange cabling or the battery enclosure." },
] as const;

export function getEraGuide(year: number) {
  return ERA_GUIDES.find((era) => year >= era.range[0] && year <= era.range[1]) ?? ERA_GUIDES[ERA_GUIDES.length - 1];
}

export function getVehicleProfile(make: string, model: string, year: number) {
  const normalizedMake = make.trim().toLowerCase();
  const normalizedModel = model.trim().toLowerCase();
  return VEHICLE_PROFILES.find((profile) => {
    const years = profile.years.match(/\d{4}/g)?.map(Number) ?? [];
    const end = profile.years.includes("present") ? new Date().getFullYear() : years[1] ?? years[0];
    return profile.make.toLowerCase() === normalizedMake &&
      (profile.model.toLowerCase() === normalizedModel || profile.model === "any") &&
      year >= (years[0] ?? 1920) && year <= end;
  });
}

export const LESSONS: Lesson[] = [
  {
    id: "hydraulic-alphabet", number: "01", title: "Meet the seven parts", kicker: "Hydraulic alphabet", level: "First build", access: "free", minutes: 8,
    summary: "Battery, solenoid, pump, check valve, dump, cylinder and switch—what each one actually does.",
    sections: [
      { heading: "Follow one lift", body: "The switch carries a small control signal. It wakes the motor solenoid, the solenoid passes heavy battery current, and the motor spins the pump. The pump pushes oil through a check valve and into a cylinder. The extending cylinder raises that corner.", bullets: ["Switch = instruction", "Solenoid = heavy-current gate", "Pump + cylinder = movement"] },
      { heading: "Follow one drop", body: "The pump does not need to run for a normal single-acting corner to drop. The switch energizes a dump coil. The dump opens a path for oil to return, and vehicle weight pushes the cylinder down. A slow-down restriction can make that return gentler." },
      { heading: "The check valve is one-way", body: "A check valve holds pressure in the corner when the pump stops and helps prevent one pump from pushing oil backward into another. In paired-pump circuits, every pump needs its own checked outlet before lines join." },
    ],
    fieldTip: "Say the path out loud—switch, solenoid, motor, pump, check valve, cylinder. If you can trace it, you can diagnose it.",
    quiz: { question: "Which part opens to let a corner drop?", options: ["The battery", "The dump", "The check valve", "The switch handle"], answer: 1, explanation: "The dump opens the return path. The switch only sends the electrical instruction." },
  },
  {
    id: "momentary-switch", number: "02", title: "Read a momentary switch", kicker: "Control basics", level: "First build", access: "free", minutes: 10,
    summary: "Common, raise and lower contacts—plus why the wiring-side view confuses beginners.",
    sections: [
      { heading: "Three positions, one spring", body: "A momentary (on)-off-(on) toggle springs back to center when released. Center should connect nothing. One direction connects common to the raise contact; the other connects common to the lower contact." },
      { heading: "Three-prong versus six-prong", body: "A three-prong SPDT switch has one pole: one common and two switched contacts. A six-prong DPDT has two independent poles in the same handle, letting one motion control two outputs in each direction. A 12-prong version can control four poles, but its exact terminal arrangement must be verified." },
      { heading: "Notch up is a drawing convention", body: "Our drawings show the wiring side with the locating notch up. On many common switches, pushing the handle toward the notch closes the contacts away from the handle direction. Brands and orientations vary, so continuity-test the actual part instead of trusting a universal color or terminal rumor." },
    ],
    fieldTip: "Bench-test one switch with a meter and label its terminals before installing the rest. That five minutes prevents a full box rewind.",
    quiz: { question: "What should happen when you release a momentary switch?", options: ["It stays on", "It returns to center off", "It reverses polarity", "It grounds the pump"], answer: 1, explanation: "The spring returns the switch to center off so pumps and dumps are not left energized." },
  },
  {
    id: "two-pump-fbss", number: "03", title: "Build a 2-pump FBSS map", kicker: "First complete system", level: "First build", access: "trial", minutes: 16,
    summary: "Two pumps, four dumps, four cylinders: front/back lift with individual corner drop.",
    sections: [
      { heading: "One pump feeds an axle", body: "Pump 1 feeds both front cylinders through a checked pressure circuit. Pump 2 feeds both rear cylinders. This gives front and rear lift, not individual corner lift." },
      { heading: "Four dumps add corner drop", body: "Each cylinder branch gets its own dump channel: FL, FR, RL and RR. Front and rear switches operate dump pairs. Corner or side switches can open selected dumps to straighten or lean the car." },
      { heading: "The seven-wire reference", body: "A typical control map uses one control feed, two pump-trigger channels and four dump-trigger channels. Our studio assigns red, black, blue, orange, yellow, green and white. Manufacturer cords vary; label by measured function, not color alone.", bullets: ["Red: fused control feed", "Black / blue: front / rear pump triggers", "Orange / yellow / green / white: FL / FR / RL / RR dumps"] },
    ],
    fieldTip: "The secret to FBSS is understanding the limit: four dumps give independent drop, but two axle pumps do not give independent lift.",
    quiz: { question: "On a standard 2-pump FBSS setup, what can each front corner do independently?", options: ["Lift only", "Dump only", "Lift and dump with no other corner moving", "Nothing"], answer: 1, explanation: "The shared front pump lifts both front corners; separate dumps allow individual drop." },
  },
  {
    id: "battery-bank", number: "04", title: "Series, parallel & control taps", kicker: "Power without guesswork", level: "Street", access: "trial", minutes: 18,
    summary: "Turn matched 12V batteries into a labeled motor bus and a balanced control supply.",
    sections: [
      { heading: "Series adds voltage", body: "Within one string, connect the negative of one battery to the positive of the next according to your verified plan. Two 12V batteries in series provide 24V nominal; four provide 48V. Measure across the complete string before connecting loads." },
      { heading: "Parallel strings add capacity", body: "Multiple strings must have the same battery count, type, age and state of charge. Parallel them at equal common bus points with matched cable practices. Do not parallel a two-battery string with a four-battery string." },
      { heading: "Control voltage is a separate decision", body: "Switches, dump coils and solenoid trigger circuits must match their ratings. If a balanced design uses a 12V or 24V tap, take the equivalent tap from every parallel string and bond the control commons correctly. Never casually tap one battery and leave the others to become unbalanced." },
    ],
    fieldTip: "Write string and battery numbers on every hold-down. During charging, compare the same numbered position in each string; differences are easier to spot.",
    quiz: { question: "Can you parallel a 24V string directly with a 48V string?", options: ["Yes, for more power", "Only with small wire", "No, matched strings are required", "Only when the car is off"], answer: 2, explanation: "Parallel strings need the same nominal voltage and matched construction." },
  },
  {
    id: "four-pump-independent", number: "05", title: "Four pumps, four corners", kicker: "Independent control", level: "Street", access: "trial", minutes: 15,
    summary: "Give every corner its own pressure source, dump channel and switch-cord trigger.",
    sections: [
      { heading: "One circuit per corner", body: "P1/FL, P2/FR, P3/RL and P4/RR each feed one cylinder through a check valve and a dedicated dump. This permits independent lift and drop instead of only independent drop." },
      { heading: "Nine-wire reference map", body: "Use one control feed, four pump triggers and four dump triggers. Combination switches connect the same output channels in useful groups: front, rear, sides, corners, pancake and see-saw." },
      { heading: "Fan out at a terminal strip", body: "A switch output may need to feed more than one destination. Land the cord on a labeled terminal strip and make deliberate jumpers there. Do not hide a bundle of twisted wires under tape." },
    ],
    fieldTip: "Use the same corner order everywhere: FL, FR, RL, RR on the drawing, rack, terminal strip and switch labels.",
    quiz: { question: "How many pump-trigger channels does a standard four-corner, four-pump control map need?", options: ["One", "Two", "Four", "Eight"], answer: 2, explanation: "Each independently lifted corner needs its own pump-trigger channel." },
  },
  {
    id: "rack-and-frame", number: "06", title: "Rack & frame planning", kicker: "The part that holds it all", level: "Street", access: "trial", minutes: 14,
    summary: "Plan service access, battery restraint and professional load paths before the welder starts.",
    sections: [
      { heading: "The rack is structural", body: "Batteries and pumps create a heavy, vibrating assembly. Its mounts need a deliberate load path into suitable frame structure. Thin trunk sheet metal is not a substitute for a supported rack." },
      { heading: "Design for the next repair", body: "Leave access to battery terminals, pump fillers, solenoid nuts and hose fittings. A beautiful rack that must be cut apart to replace one solenoid is not finished. Use insulated covers and hold-downs that restrain every battery." },
      { heading: "Welding is a separate skill", body: "Fuel removal, fire watch, metal preparation, module isolation and weld inspection belong in the fabrication plan. A wiring tutorial cannot make an unsafe weld safe. Hire this portion if you are not qualified." },
    ],
    fieldTip: "Make a cardboard rack template and include your hands, a wrench and a battery lift path in the mock-up—not just the parts.",
    quiz: { question: "What should carry the rack's load?", options: ["Trunk sheet metal only", "A designed frame-supported structure", "The pressure hoses", "The switch cord"], answer: 1, explanation: "The rack needs a suitable structural load path and secure battery restraint." },
  },
  {
    id: "six-pump", number: "07", title: "Six-pump paired circuits", kicker: "Advanced pressure planning", level: "Advanced", access: "pro", minutes: 18,
    summary: "Add a second checked pump to each front or rear corner without creating six random outputs.",
    sections: [
      { heading: "Six pumps still means four corners", body: "Our six-pump plan pairs two pumps at each front corner and uses one at each rear corner, or reverses that emphasis. Each corner remains one hydraulic circuit with one dump channel." },
      { heading: "Checks come before the junction", body: "Each of the paired pumps has its own check valve. Only after those checks do pressure lines join the corner manifold. This reduces back-feeding and makes the circuit serviceable." },
      { heading: "One trigger can fan out", body: "A corner's switch-cord pump channel can feed a labeled terminal that triggers both paired solenoid banks, provided all coil ratings and current demands are correctly engineered. The heavy motor current still travels through the solenoids, never through the switch box." },
    ],
    fieldTip: "Label pairs P1A/P1B style on your own build sheet. A pair is a team feeding one corner, not a new corner.",
    quiz: { question: "Where do paired pump lines join?", options: ["Before either check valve", "After each pump's own check valve", "Inside the switch box", "At the battery negative"], answer: 1, explanation: "Each outlet is checked before the lines join the common corner circuit." },
  },
  {
    id: "eight-pump", number: "08", title: "Eight-pump competition logic", kicker: "Two pumps per corner", level: "Advanced", access: "pro", minutes: 20,
    summary: "Organize four paired pressure circuits, four dump channels and serviceable high-current banks.",
    sections: [
      { heading: "Think in pairs", body: "Pumps 1–2 feed FL, 3–4 feed FR, 5–6 feed RL and 7–8 feed RR. Each pair joins only after individual check valves. Four corner dumps complete the basic control map." },
      { heading: "Power grows faster than wire count", body: "The switch cord can still use four pump-trigger channels because each channel fans out to a pair. The high-current installation, however, has eight motor/solenoid banks and needs carefully engineered bus, cable and disconnect capacity." },
      { heading: "Competition is not street defaults", body: "Higher energy increases structural, thermal and maintenance demands. Motor duty cycle, frame reinforcement, charging and battery condition must be treated as a complete system. More voltage is not a substitute for a sound chassis." },
    ],
    fieldTip: "Build and test one paired corner on the bench before duplicating it four times. Repetition is easy; correcting four repeated mistakes is not.",
    quiz: { question: "How many basic corner dump channels are in our eight-pump plan?", options: ["Two", "Four", "Eight", "Sixteen"], answer: 1, explanation: "Two pumps share each corner circuit; each corner still has one basic dump channel." },
  },
  {
    id: "accumulators", number: "09", title: "Accumulators & slow-downs", kicker: "Control the hit", level: "Advanced", access: "pro", minutes: 12,
    summary: "Separate ride cushioning from drop speed, and adjust only with the car safely supported.",
    sections: [
      { heading: "Two different jobs", body: "An accumulator uses a separated gas charge to provide compliance in the hydraulic circuit. A slow-down restricts flow to reduce speed. They can complement each other, but one does not replace the other." },
      { heading: "Precharge is not improvisation", body: "Nitrogen precharge and service procedures must follow the accumulator manufacturer. Use rated components and correct gas-service equipment. Never use oxygen or compressed air as a substitute for specified nitrogen service." },
      { heading: "Adjust in small steps", body: "With the vehicle supported mechanically and nobody in a crush zone, make one small slow-down adjustment at a time. Document the setting for each corner and recheck for leaks or hose movement." },
    ],
    fieldTip: "A smoother cruiser is usually won with geometry, structure and controlled flow—not simply a larger pump or more batteries.",
    quiz: { question: "What is a slow-down's primary job?", options: ["Charge the battery", "Restrict flow to control speed", "Reinforce the frame", "Trigger the solenoid"], answer: 1, explanation: "It meters hydraulic flow; an accumulator provides gas-charged compliance." },
  },
  {
    id: "ten-switch-box", number: "10", title: "Wire a 10-switch box", kicker: "From empty box to labeled cord", level: "Advanced", access: "pro", minutes: 24,
    summary: "Front, rear, sides, four corners, pancake and see-saw with meter-verified contacts.",
    sections: [
      { heading: "Make the map before stripping wire", body: "Write all ten commands and list the exact outputs each direction must energize. Assign three-, six- or 12-prong switches from pole count, then draw the common feed and every jumper." },
      { heading: "Daisy-chain deliberately", body: "Run the fused control feed from common to common with one properly terminated wire in and one out at each point. Route pump channels to raise contacts and dump channels to lower contacts according to your meter-verified orientation." },
      { heading: "Test every cell of the matrix", body: "With all battery power disconnected, check center-off isolation and both directions of every switch. Then test at the terminal strip: each switch command should continuity-connect only its intended control channels." },
    ],
    fieldTip: "Take a clear photo of the completed wiring side and print the terminal map. Store both with the car for the next owner—or the next midnight repair.",
    quiz: { question: "What is the last bench test before connecting vehicle power?", options: ["Paint the box", "Continuity-test every switch and output", "Cut the labels off", "Bypass the fuse"], answer: 1, explanation: "A complete unpowered continuity matrix catches wrong contacts and unintended jumpers." },
  },
  {
    id: "meter-diagnosis", number: "11", title: "Diagnose with a meter", kicker: "No-lift decision tree", level: "Advanced", access: "pro", minutes: 16,
    summary: "Separate control faults, high-current faults and hydraulic faults without random parts swapping.",
    sections: [
      { heading: "Start at the symptom", body: "If nothing clicks, investigate control feed and commons. If a solenoid clicks but the motor does not run, investigate high-current supply, contacts, ground and motor. If the motor runs but no corner rises, move to fluid level, checks, plumbing and mechanical travel." },
      { heading: "Measure under the right condition", body: "A voltage reading with no load can look normal while a corroded connection fails under current. Compare voltage drop across a connection during a brief, safe commanded operation. Stop if parts become hot, stuck or unstable." },
      { heading: "One change at a time", body: "Record the reading, correct one fault and repeat the same test. Swapping multiple parts destroys the evidence. Disconnect power before resistance or continuity tests and never meter a live high-energy circuit beyond your training." },
    ],
    fieldTip: "A loud click only proves part of the story. It does not prove the main contacts pass current or that hydraulic pressure reaches the cylinder.",
    quiz: { question: "A solenoid clicks but the motor stays silent. What area comes next?", options: ["High-current feed, contacts, ground and motor", "Switch handle color", "Cylinder paint", "Tire pressure only"], answer: 0, explanation: "The click suggests some control response; the next branch is the high-current path." },
  },
  {
    id: "maintenance", number: "12", title: "The 15-minute recheck", kicker: "Keep the build reliable", level: "First build", access: "free", minutes: 9,
    summary: "A repeatable leak, battery, cable and hardware inspection with the car mechanically supported.",
    sections: [
      { heading: "Make it a routine", body: "After the first test session and at regular intervals, isolate power and support the vehicle mechanically. Look for wet fittings, chafed hoses, loose hold-downs, damaged terminal covers and changed wire routing." },
      { heading: "Compare, do not guess", body: "Record individual battery voltages using your normal charging procedure. Compare equivalent positions across strings and investigate meaningful differences with compatible charging and battery guidance." },
      { heading: "Keep contamination out", body: "Clean around caps before opening, cap disconnected lines immediately and use only the fluid specified for your components. Dirt inside a precision valve can become a mysterious intermittent fault later." },
    ],
    fieldTip: "Keep a small notebook in the trunk: date, battery readings, leaks, changed fittings and switch behavior. Patterns solve problems.",
    quiz: { question: "What supports the car during a close underside inspection?", options: ["Hydraulic pressure only", "A held switch", "Rated mechanical stands/supports", "The dump coils"], answer: 2, explanation: "Hydraulics are not a safety support. Use rated mechanical supports." },
  },
];

export const SHOP_NOTES = [
  { title: "Colors are a language, not a law", body: "Assign your own legend, label both ends and meter unknown cords. Another builder's red wire may not be your red wire." },
  { title: "Draw the wiring side", body: "Mark every drawing 'wiring side / notch up.' Most reversed up/down mistakes begin with viewing the handle side instead." },
  { title: "One output, one landing point", body: "Use labeled terminal strips for fan-out. Hidden taped splices turn a simple diagnosis into a full harness removal." },
  { title: "Leave a service loop", body: "A neat harness still needs enough movement to remove a switch box or rack component without cutting the cord." },
  { title: "Pair pumps after checks", body: "Six- and eight-pump systems stay understandable when every outlet is checked before paired pressure lines meet." },
  { title: "A click is not current", body: "A solenoid can click and still have burned main contacts. Test the power path instead of celebrating the sound." },
  { title: "Charge the bank as a system", body: "Matched strings and balanced taps only work when charging is designed for the bank. Random automotive chargers can leave hidden imbalance." },
  { title: "Protect the quiet wires", body: "Switch and dump wiring needs its own fuse, strain relief and abrasion protection even though it carries less current than motor cable." },
  { title: "Slow is a valid test speed", body: "First movement should be a controlled, supported test—not a full-voltage hop. Verify labels before chasing speed." },
  { title: "Photograph every layer", body: "Take pictures before the rack cover, terminal strip and box back go on. Future you gets an X-ray of the build." },
  { title: "Keep the factory car separate", body: "Do not power a hydraulic system from random factory accessory feeds. Plan isolated power and protect original safety electronics." },
  { title: "Write the next repair into the design", body: "If a solenoid nut cannot accept a wrench or a battery cannot lift out, the rack is not finished yet." },
];

export const DIAGNOSTICS = [
  { id: "silent", symptom: "Nothing clicks or moves", likely: "Control supply or service disconnect", steps: ["Isolate the system and inspect the control fuse, disconnect and visible connectors.", "With a safe test plan, verify the specified control voltage at the switch-cord supply.", "Check continuity from control common to each switch common with power disconnected.", "Test one known switch output at the terminal strip before suspecting pumps."] },
  { id: "click-no-motor", symptom: "Solenoid clicks, motor stays silent", likely: "High-current path", steps: ["Stop if the solenoid sticks, smokes or becomes hot; disconnect power.", "Inspect main battery cables, ground, lugs and solenoid main-post tightness.", "Test motor-bus voltage and voltage drop under a brief controlled command.", "Evaluate solenoid main contacts and motor only after supply and ground tests."] },
  { id: "motor-no-lift", symptom: "Motor runs but corner will not rise", likely: "Hydraulic or mechanical path", steps: ["Stop the motor and check reservoir level using the component maker's procedure.", "Inspect for external leaks, incorrect line routing and closed or damaged fittings.", "Verify the check-valve direction and that the selected pump feeds the intended corner.", "With mechanical support, inspect for binding or interference in cylinder travel."] },
  { id: "no-dump", symptom: "One corner will not drop", likely: "Dump trigger, coil or return path", steps: ["Compare the affected dump's control feed with a working corner using a safe meter plan.", "Check the switch output and terminal-strip landing for that exact dump label.", "Inspect the coil connector and confirm the coil voltage rating matches control supply.", "If electrical operation is confirmed, follow the valve maker's mechanical service procedure—do not open pressurized parts."] },
  { id: "weak", symptom: "Everything feels slow or weak", likely: "Voltage drop, charge or flow restriction", steps: ["Record every battery at rest using your normal charging procedure and compare matched strings.", "Inspect ground and positive connections for corrosion, heat marks and poor crimps.", "Measure voltage drop during a brief safe operation; a no-load reading is not enough.", "Check fluid specification, slow-down settings and mechanical binding before adding voltage."] },
  { id: "hot-switch", symptom: "A switch or small wire gets hot", likely: "Overload, short or wrong connection", steps: ["Release the switch and disconnect system power immediately.", "Do not continue operating or install a larger fuse to hide the symptom.", "Inspect for a direct motor load on switch wiring; switches should only carry designed control loads.", "Continuity-test the box for unintended jumpers and repair damaged wire before retesting."] },
  { id: "imbalance", symptom: "Batteries charge or drain unevenly", likely: "String mismatch, taps or charging", steps: ["Label and record each battery's voltage and equivalent position in every string.", "Verify all parallel strings have equal series counts and matched batteries.", "Inspect control-tap symmetry and common bus connections.", "Review the charger arrangement with its manufacturer; do not keep cycling an imbalanced bank."] },
] as const;
