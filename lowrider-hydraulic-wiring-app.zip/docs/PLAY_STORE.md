# Google Play release path

Switchcraft ships as an installable Progressive Web App. A Google Play listing is **not** claimed in the preview. Publishing requires the site owner's domain, signing keys and Google Play Developer account.

## 1. Production prerequisites

- Deploy the production app on a verified HTTPS domain.
- Replace the generated icon with final brand artwork if needed; keep 512 px and maskable safe areas.
- Test installation, offline fallback, Stripe return URLs and all external vendor links on physical Android devices.
- Complete a privacy policy, account/data deletion instructions, membership terms and safety disclaimer suitable for the published service.

## 2. Package a Trusted Web Activity

Use Google's Bubblewrap tooling in a release environment:

```sh
npm install -g @bubblewrap/cli
bubblewrap init --manifest=https://YOUR_VERIFIED_DOMAIN/manifest.webmanifest
bubblewrap build
```

Choose the final application ID (for example, a domain owned by the publisher), version code and signing key during `init`. Keep the upload key private and back it up securely. Do not commit it to this repository.

## 3. Prove domain ownership

Bubblewrap outputs the SHA-256 certificate fingerprint required in Digital Asset Links. Publish the generated statement at:

`https://YOUR_VERIFIED_DOMAIN/.well-known/assetlinks.json`

No statement file is included here because a placeholder fingerprint would not verify a real app. Use the fingerprint from the actual release/upload key and the real package name.

## 4. Test and publish

1. Install the signed release bundle on test devices and confirm there is no browser URL bar after asset-link verification.
2. Create an internal or closed test track in Google Play Console.
3. Complete app content, data safety, content rating, ads and subscription disclosures.
4. Link the real Stripe/Google Play billing approach required by current Play policy. Digital goods subscriptions may require Google Play Billing; confirm current policy before release rather than assuming web Stripe checkout is sufficient.
5. Upload the Android App Bundle, submit store listing assets and pass review.

## Launch truthfulness

Until those steps are complete, the product UI continues to say “not yet listed on Google Play” and offers the working browser installation flow instead.
